'''
@Auther: Melt_Min
@Author:Sun_Zhao
@Last Modify: 2024-09-26
@Usage: 相機調用
'''
# -- coding: utf-8 --

import sys
# import copy
# import termios

# from ctypes import *
import numpy as np
import cv2
from Tool import Tool

import time
import threading
# from Tool import Tool
# from ConfigManager import ConfigManager
# import json

GET_FRAME_NUM = 0
START_TIME = 0
LAST_TIME = 0
MCC = None


def import_src_fun():
    global MCC
    MCC = __import__("MvCameraControl_class")


class HikvisionCamera(object):
    def __init__(self, tool,mvimport_src=None, config={}):
        if mvimport_src is None:
            sys.path.append("/opt/MVS/Samples/64/Python/MvImport")
        else:
            sys.path.append(mvimport_src)
        import_src_fun()
        self.Tool = tool
        self.cam = None
        self.image = None
        self.read_finished = False
        self.config = config
        self.__new_thread()
        self.ready = False

    def __new_thread(self):
        self.thread = threading.Thread(target=self.__open_camera, daemon=True)
        self.thread.start()

    def __FrameInfoCallBack(self):
        winfun_ctype = MCC.CFUNCTYPE
        stFrameInfo = MCC.POINTER(MCC.MV_FRAME_OUT_INFO_EX)
        pData = MCC.POINTER(MCC.c_ubyte)
        return winfun_ctype(None, pData, stFrameInfo, MCC.c_void_p)

    def __callback(self, pData, pFrameInfo, pUser):
            stFrameInfo = MCC.cast(pFrameInfo, MCC.POINTER(MCC.MV_FRAME_OUT_INFO_EX)).contents
            stConvertParam = MCC.MV_SAVE_IMAGE_PARAM_EX()
            try:
                bmp_buf = (MCC.c_ubyte * (stFrameInfo.nWidth * stFrameInfo.nHeight * 3 + 1024))()
            except MemoryError:
                self.Tool.printError("Memory allocation failed")
                self.image = None
                self.read_finished = True
            else:
                MCC.memset(MCC.byref(stConvertParam), 0, MCC.sizeof(MCC.MV_SAVE_IMAGE_PARAM_EX))
                stConvertParam.enImageType = MCC.MV_Image_Bmp
                stConvertParam.enPixelType = stFrameInfo.enPixelType
                stConvertParam.nBufferSize = stFrameInfo.nWidth * stFrameInfo.nHeight * 3 + 1024
                stConvertParam.nWidth = stFrameInfo.nWidth
                stConvertParam.nHeight = stFrameInfo.nHeight
                stConvertParam.pData = pData
                stConvertParam.nDataLen = stFrameInfo.nWidth * stFrameInfo.nHeight * 3 + 1024
                stConvertParam.pImageBuffer = bmp_buf

                
                # ret = self.cam.MV_CC_SaveImageEx2(stConvertParam)
                ret = 0
                if ret!= 0:
                    self.Tool.printError("failed in MV_CC_SaveImage,nRet[0x%x]" % ret)
                    self.image = None
                    self.read_finished = True

                else:
                    img_buff = (MCC.c_ubyte * stConvertParam.nDataLen)()
                    MCC.memmove(MCC.byref(img_buff),stConvertParam.pImageBuffer, stConvertParam.nDataLen)
                    nparr = np.frombuffer(img_buff, np.uint8)
                    self.image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                    while self.image is not None and self.image.size != 0:
                        self.read_finished = True
                        break

    def __open_camera(self):
        SDKVersion = MCC.MvCamera.MV_CC_GetSDKVersion()
        self.Tool.print("SDKVersion[0x%x]" % SDKVersion)

        deviceList = MCC.MV_CC_DEVICE_INFO_LIST()
        tlayerType = MCC.MV_GIGE_DEVICE | MCC.MV_USB_DEVICE

        # ch:枚举设备 | en:Enum device
        ret = MCC.MvCamera.MV_CC_EnumDevices(tlayerType, deviceList)
        if ret != 0:
            self.Tool.printError("Enum devices fail! ret[0x%x]" % ret)
            return 

        if deviceList.nDeviceNum == 0:
            self.Tool.printError("Find no device!")
            return 

        self.Tool.print("Find %d devices!" % deviceList.nDeviceNum)
        for i in range(0, deviceList.nDeviceNum):
            mvcc_dev_info = MCC.cast(deviceList.pDeviceInfo[i], MCC.POINTER(
                MCC.MV_CC_DEVICE_INFO)).contents
            if mvcc_dev_info.nTLayerType == MCC.MV_GIGE_DEVICE:
                self.Tool.print("\nGige device: [%d]" % i)
                strModeName = ""
                for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chModelName:
                    strModeName = strModeName + chr(per)
                self.Tool.print("Device model name: %s" % strModeName)

                nip1 = (
                    (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0xff000000) >> 24)
                nip2 = (
                    (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x00ff0000) >> 16)
                nip3 = (
                    (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x0000ff00) >> 8)
                nip4 = (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x000000ff)
                self.Tool.print("Current ip: %d.%d.%d.%d\n" %
                                (nip1, nip2, nip3, nip4))
            elif mvcc_dev_info.nTLayerType == MCC.MV_USB_DEVICE:
                self.Tool.print("\nU3v device: [%d]" % i)
                strModeName = ""
                for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chModelName:
                    if per == 0:
                        break
                    strModeName = strModeName + chr(per)
                self.Tool.print("Device model name: %s" % strModeName)

                strSerialNumber = ""
                for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chSerialNumber:
                    if per == 0:
                        break
                    strSerialNumber = strSerialNumber + chr(per)
                self.Tool.print("User serial number: %s" % strSerialNumber)
        if deviceList.nDeviceNum > 1:
            self.Tool.print(f"Find {deviceList.nDeviceNum} camera device(s)")
            if self.config["IP"]=="10.64.58.5":
                nConnectionNum = 0
            elif self.config["IP"]=="10.64.57.5":
                nConnectionNum = 1
        else:
            self.Tool.printWarning(
                     (f"find {deviceList.nDeviceNum}  use camera index 0(default)"))
            nConnectionNum = 0
        # ch:创建相机实例 | en:Creat Camera Object
        self.cam = MCC.MvCamera()
        stDeviceList = MCC.cast(deviceList.pDeviceInfo[int(
            nConnectionNum)], MCC.POINTER(MCC.MV_CC_DEVICE_INFO)).contents
        ret = self.cam.MV_CC_CreateHandle(stDeviceList)
        if ret != 0:
            self.Tool.printError("[Camera] 相機創建句柄失敗! ret[0x%x]" % ret)
            return
        # ch:打开设备 | en:Open device
        try:
            ret = self.cam.MV_CC_OpenDevice(MCC.MV_ACCESS_Exclusive, 0)
        except BaseException as e:
            print(e)
        if ret != 0:
            self.Tool.printError("[Camera] 相機%d打開失敗! ret[0x%x]" % (nConnectionNum,ret))
            return
        else:
            print('camera %d open Successfully' %nConnectionNum)
        # ch:探测网络最佳包大小(只对GigE相机有效) | en:Detection network optimal package size(It only works for the GigE camera)
        if stDeviceList.nTLayerType == MCC.MV_GIGE_DEVICE:
            nPacketSize = self.cam.MV_CC_GetOptimalPacketSize()
            if int(nPacketSize) > 0:
                ret = self.cam.MV_CC_SetIntValue("GevSCPSPacketSize", nPacketSize)
                if ret != 0:
                    self.Tool.printWarning(
                        "[Camera] 相機獲取最佳網絡包失敗! ret[0x%x]" % ret)
            else:
                self.Tool.printWarning(
                    "[Camera] 相機獲取最佳網絡包失敗! ret[0x%x]" % nPacketSize)

        ret = self.cam.MV_CC_SetEnumValue("AcquisitionMode", MCC.MV_ACQ_MODE_CONTINUOUS)
        if ret != 0:
            self.Tool.printError("Set acquisition mode fail! ret[0x%x]" % ret)
            return
        # ret = self.cam.MV_CC_SetEnumValue("TriggerMode", MCC.MV_TRIGGER_MODE_OFF)
        ret = self.cam.MV_CC_SetEnumValue("TriggerMode", MCC.MV_TRIGGER_MODE_ON)
        if ret != 0:
            self.Tool.printError("Set trigger mode fail! ret[0x%x]" % ret)
            return
        
        ret = self.cam.MV_CC_SetEnumValue("TriggerSource", MCC.MV_TRIGGER_SOURCE_SOFTWARE);
        if ret != 0:
            self.Tool.printError("MV_CC_SetTriggerSource fail! nRet [0x%x]\n" % ret)
            return

        # ch:注册抓图回调 | en:Register image callback
        
        CALL_BACK_FUN = self.__FrameInfoCallBack()(self.__callback)
        ret = self.cam.MV_CC_RegisterImageCallBackEx(CALL_BACK_FUN, None)
        if ret != 0:
            self.Tool.printError(
                "[Camera] 相機註冊回調失敗! ret[0x%x]" % ret)
            return

        ret = self.cam.MV_CC_StartGrabbing()
        if ret != 0:
            self.Tool.printError("[Camera] 相機開始取流失敗! ret[0x%x]" % ret)
            return

        self.Tool.print("[Camera %d] 相機運行中.." %nConnectionNum)
        self.ready = True
        while True:
            pass


    def close_camera(self):
        self.Tool.print("Close camera..")
        if self.cam is not None:
        # ch:停止取流 | en:Stop grab image
            try:
                ret = self.cam.MV_CC_StopGrabbing()
                if ret != 0:
                    self.Tool.printError("[Camera] 相機停止取流失敗! ret[0x%x]" % ret)
                    return

                # ch:关闭设备 | Close device
                ret = self.cam.MV_CC_CloseDevice()
                if ret != 0:
                    self.Tool.printError("[Camera] 设备關閉失敗! ret[0x%x]" % ret)
                    return

                # ch:销毁句柄 | Destroy handle
                ret = self.cam.MV_CC_DestroyHandle()
                if ret != 0:
                    self.Tool.printError("[Camera] 銷毀句柄失敗! ret[0x%x]" % ret)
                    return
            except Exception as e:
                self.Tool.printError(f"相机关闭失败 {e}")

        self.Tool.print("[Camera] 關閉相機作業結束.",True)


    def get_image(self,i):
        while not self.ready:
            time.sleep(0.1)
        nRet = self.cam.MV_CC_SetCommandValue("TriggerSoftware")
        if 0 != nRet:
            self.Tool.printError("failed in TriggerSoftware[0x%x]" %nRet)
            return None
        else:
            while not self.read_finished:
                time.sleep(0.1)
            self.read_finished = False
            return self.image

if __name__ == "__main__":
    # cam = HikvisionCamera(Tool())
    # # time.sleep(3)
    # i = 15004
    # while True:
    #     res= cam.get_image(i)
    #     cv2.imwrite(f"image/{i}.jpg",res)
        # i = i + 1
    a = [1,2,3]
    if  1 not in a:
        print("OK")
    