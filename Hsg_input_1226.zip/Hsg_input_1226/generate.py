# def generate_data(self):
#         global SCAN_RATE_LAST_HOUR,UPH_LAST_HOUR
#         current_time = datetime.now()
#         while True:
#             # 每5分钟生成一个数据点
#             if len(UPH_TIME) == 0 or current_time >= UPH_TIME[-1] + timedelta(minutes=5):
#                 UPH_TIME.append(current_time)
#                 UPH_PER_5MIN.append(random.randint(0, 650))  # 随机生成数据量
#                 SCAN_TIME.append(current_time)
#                 SCAN_RATE_PER_5MIN.append(random.randint(0, 650))
#                 SCAN_RATE_LAST_HOUR = round(random.uniform(0, 100), 2)
#                 UPH_LAST_HOUR = round(random.uniform(0, 100), 2)

#                 if len(UP_IMAGE_INFO_TABLE) < UP_IMAGE_INFO_TABLE.maxlen:
#                     up_image_info_number = len(UP_IMAGE_INFO_TABLE) + 1
#                 else:
#                     up_image_info_number = up_image_info_number + 1
#                 # 添加新数据到表格
#                 up_image_info_new_row = {
#                     'no': up_image_info_number,
#                     'upload_time': current_time.strftime('%Y-%m-%d %H:%M:%S'),
#                     'sn': f'SN{len(UP_IMAGE_INFO_TABLE) + 1}',
#                     'predict_result': round(random.uniform(0, 100), 2),
#                     'sf_info': '信息' + str(len(UP_IMAGE_INFO_TABLE) + 1)
#                 }
#                 UP_IMAGE_INFO_TABLE.append(up_image_info_new_row)

#                 if len(DOWN_IMAGE_INFO_TABLE) < DOWN_IMAGE_INFO_TABLE.maxlen:
#                     down_image_info_number = len(DOWN_IMAGE_INFO_TABLE) + 1
#                 else:
#                     down_image_info_number = down_image_info_number + 1
#                 # 更新另一个表格的数据
#                 down_image_info_new_row = {
#                     'no': down_image_info_number,
#                     'upload_time': current_time.strftime('%Y-%m-%d %H:%M:%S'),
#                     'sn': f'SN{len(DOWN_IMAGE_INFO_TABLE) + 1}',
#                     'predict_result': round(random.uniform(0, 100), 2),
#                     'sf_info': '信息' + str(len(DOWN_IMAGE_INFO_TABLE) + 1)
#                 }
#                 DOWN_IMAGE_INFO_TABLE.append(down_image_info_new_row)
#                 current_time += timedelta(minutes=5)
#             time.sleep(1)  # 每0.4秒检查一次