
from collections import deque
import os
import time
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class CustomFileHandler(FileSystemEventHandler):
    def __init__(self):
        super().__init__()

    def on_created(self, event):
        if not event.is_directory:
            print(f"File created: {event.src_path}")
            

    def my_task(self,args):
        # 模拟处理任务
        while True:
            time.sleep(1)  # 假设处理任务需要5秒钟
            print(f"Finished processing file: {args}")

if __name__ == "__main__":
    #  serial_port = {}
    #  with open('USB.txt','r',encoding='utf-8') as data:
    #     serial_list=data.readlines()
    #  for serial_info in serial_list:
    #     port_list = serial_info.split(">")[-1].split('/')
    #     if port_list[7] == '1-4:1.0':
    #         serial_port['plc_serial_port'] = "/dev/"+port_list[-1].replace("\n", '')
    #     elif port_list[7] == '1-6:1.0':
    #         serial_port['triple_light_port'] = "/dev/"+port_list[-1].replace("\n", '')
    #  print(serial_port)
    with open('kaikai.sh','w',encoding='utf-8') as usb_sh:
        usb_sh.writelines(['#!/bin/sh\n','ls -l /sys/class/tty/ttyUSB* > USB.txt'])