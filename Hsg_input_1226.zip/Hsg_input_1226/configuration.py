import os
from pathlib import Path

from Tool import Tool

tool = Tool()

def get_serial_port(tool):
    try:
        serial_port = {}
        if not os.path.exists('USB.sh'):
            with open('USB.sh','w',encoding='utf-8') as usb_sh:
                usb_sh.writelines(['#!/bin/sh\n','ls -l /sys/class/tty/ttyUSB* > USB.txt'])
        os.system('./USB.sh')
        os.system('chmod 554 USB.sh')
        with open('USB.txt','r',encoding='utf-8') as data:
            serial_list=data.readlines()
        for serial_info in serial_list:
            port_list = serial_info.split(">")[-1].split('/')
            if port_list[7] == '1-4:1.0':
                serial_port['plc_serial_port'] = "/dev/"+port_list[-1].replace("\n", '')
            elif port_list[7] == '1-6:1.0':
                serial_port['triple_light_port'] = "/dev/"+port_list[-1].replace("\n", '')
        return serial_port
    except Exception as e:
        tool.printError(e)

Serial_Info = get_serial_port(tool)

class Configuration():
    
    #选择使用Cambrian预测还是Local预测
    predictUrl = "Local"
    # 是否启用双层网络
    bIsSubNetwork = "False"
    # 机种名称
    ServiceProductName = "Meerkat"
    #备用236服务器地址
    BackUpServerIp = "172.28.131.236"
    #备用236服务器地址上传URL
    BackUpServerIpUploadUrl = "http://172.28.131.236:6666/upload_sfis"
    #备用236服务器连接测试端口号
    BackUpServerIpPort = 6666
    # Local服务器地址
    LocalServerIp = "172.28.131.237"
    # Local服务器连接测试次数
    LocalServerRetryTimes = 3
     # Local服务器重试间隔时间的基数
    BackoffFactor = 0.3
    # Local服务器上相机预测图片端口号
    LocalServerPortUp = 5300
    # Local服务器下相机预测图片端口号
    LocalServerPortDown = 5400
     # 上相机图片预测URL
    UpImagePredictionUrl = "http://172.28.131.237:5300/prediction/"
    # 下相机图片预测URL
    DownImagePredictionUrl = "http://172.28.131.237:5400/prediction/"
    #LOCAL_SERVER 小网络上相机图片预测URl
    UpImagePredictionSubURL = "http://127.0.0.1:6020/prediction2/"
    #LOCAL_SERVER 小网络下相机图片预测URl
    DownImagePredictionSubURL = "http://127.0.0.1:6020/prediction2/"
    #站位名称
    ServiceCallerID = "PGPD_F02-4FP-02_1_HSG-AOI"
    #临时图片保存文件夹
    DataSetDir = os.path.join(os.path.dirname(os.path.abspath(__file__)),'input')
    #预测None图片保存文件夹
    UpLoadFailDir = os.path.join(os.path.dirname(os.path.abspath(__file__)),'NonePredict')
     #上传236失败图片保存文件夹
    UpLoadBackupFailDir = os.path.join(os.path.dirname(os.path.abspath(__file__)),'UploadBackupFail')
    #上相机图片保存目录
    ImageUpDir = os.path.join(os.path.join(Path.home(),"Desktop"),"IMAGE_UP")
    #下相机图片保存目录
    ImageDownDir = os.path.join(os.path.join(Path.home(),"Desktop"),"IMAGE_DOWN")
    #信息记录文件夹
    RECORD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),'Record')
    #上相机图片保存数量
    ImageUpNum = 100
    #下相机图片保存数量
    ImageDownNum = 100
    # 上传backupServer后多少分钟再次尝试上传LocalServer
    IntervalConnectToLocal = 5
    # 连接超时时间
    TimeOut = 10
    # CAMBRIAN_SERVER地址
    CambrianServer = "http://serving2.cambrian.psh.corp.pegatron/api/v2/serving/predict_check"
    #專案token (主網路) 連Cambrian Server 參數
    ServiceToken = "a2d65f259957526dd640aa6ddcbe0e85"
    #案子名稱 (EX : Trirobite)
    ServiceName = "D38_HSGCHECK_Parent_20231109"
     #ServiceVersion = 模型的版本
    ServiceVersion = "v0.0.0.23"
    #ServiceWeightVersion = 模型的版本時間
    ServiceWeightVersion = "v0.0.0.0.20221010112538"
    #專案token (子網路)
    SubServiceToken = "57a20ca465d8e6fd8db8927104b0ac83"
    #案子名稱 (EX : Trirobite)
    SubServiceName = "D28_hsginput_multi_1010"
    #ServiceVersion = 模型的版本
    SubServiceVersion = "v0.0.0.0"
    #ServiceWeightVersion = 模型的版本時間
    SubServiceWeightVersion = "v0.0.0.0.20221010112538"
    #ISN的長度是否要檢查的開關  Ture = 1, False = 0 不符合指定長度不做predict
    bSNLengthCheck = 0
    # predict 失败后多久进行再次上传 单位秒
    repredictInterval = 1.5
    #是否要上傳SFIS
    UploadToSFIS = False
    #ISN 應有的長度
    iSNLength = 23,18
    #上相机IP
    UpCameraIp = "10.64.57.7"
    #下相机IP
    DownCameraIp = "10.64.58.7"
    #扫码器IP
    BarcodeScannerIp = "192.168.1.100"
    #扫码器端口
    BarcodeScannerPort = "9102"
    #三色灯端口
    ThreeColorLightSerial = Serial_Info.get('triple_light_port','')
    #三色灯波特率
    ThreeColorLightBaudrate = 9600
    # 三色灯 bytesize
    ThreeColorLightBytesize = 8
    # 三色灯 校验位
    ThreeColorLightParity = 'E'
    # 三色灯 停止位
    ThreeColorLightStopbits =1 
    #PLC端口
    PlcSerial = Serial_Info.get('plc_serial_port','')
    # PLC 波特率
    PlcBaudrate = 9600
    # PLC bytesize
    PlcBytesize = 8
    # PLC 校验位
    PlcParity = 'E'
    # PLC 停止位
    PlcStopbits =1 
    # PLC 请求超时时间
    PlcTimeout = 1
    #收到下相机可拍照信号后的延迟 单位秒
    delayTime = 0.5
    # 上相机图像品质
    UpImageQuality = 50
    # 下相机图像品质
    DownImageQuality = 50
    # 打开绿灯(常亮)
    GreenLightAlwaysOn = bytes.fromhex("01 05 00 02 ff 00 2D FA")
    #红灯闪烁(2Hz)
    RedlightBlinking = bytes.fromhex("01 05 00 00 f0 00 89 CA")
    #蜂鸣器模式1(2Hz)
    BuzzerModeOne = bytes.fromhex("01 05 00 03 f0 00 79 CA")
    #关闭红色
    TurnOffRedLight = bytes.fromhex("01 05 00 00 00 00 CD CA")
    #关闭蜂鸣器
    TurnOffBuzzer = bytes.fromhex("01 05 00 03 00 00 3D CA")
    # 闪烁与蜂鸣时间 (秒)
    Alarm_Duration = 1