import time
import requests
import json
import os
import socket
from urllib3 import PoolManager
from configuration import Configuration
import cv2
from requests.adapters import HTTPAdapter
# from urllib3.util.retry import Retry

def get_local_ip(tool,server_ip):
    s = None
    try:
        # 创建一个UDP套接字
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # 连接到一个公共DNS服务器（例如Google的8.8.8.8），以获取本机IP
        s.connect(("8.8.8.8", 80))
        # 获取本机IP地址
        ip = s.getsockname()[0]
        tool.print(f"与服务器 {server_ip}通信的本机IP为 {ip}",True)
        return ip
    except Exception:
        tool.printError(f"获取本地IP失败!!!")
        raise 
    finally:
        if not s is None:
            s.shutdown(socket.SHUT_RDWR)
            s.close()

class LocalHostAdapter(HTTPAdapter):
    def __init__(self, local_ip, *args, **kwargs):
        self.local_ip = local_ip
        super().__init__(*args, **kwargs)

    def init_poolmanager(self, connections, maxsize, block=False, **pool_kwargs):
        pool_kwargs['source_address'] = (self.local_ip, 0)
        self.poolmanager = PoolManager(num_pools=connections, maxsize=maxsize, block=block, **pool_kwargs)

class CambrianPrediction():

    def __init__(self):
      self.input_json = {
        'number_of_input': 1,
        'inputs': [
            {
                'caller_id':Configuration.ServiceCallerID, 
                'part_id': '',
                'input_id':1,
                'product_name':Configuration.ServiceProductName,
                'height': 3000,
                'width': 5200,
                'file_name': "",
                'dut_sn':'',
                'upload_sfis':Configuration.UploadToSFIS
            }
        ]
    }
      self.subModels = {
        'detail': {
            'Service-Token':  Configuration.SubServiceToken,  
            'Service-Name':  Configuration.SubServiceName,
            'Service-Version': Configuration.SubServiceVersion,
            'Service-Weight': Configuration.SubServiceWeightVersion    
        }
    }
      
    def predict(self,file_path):
       model_info_headers = {
        'Service-Token':  Configuration.ServiceToken,   # 大網路模型信息
        'Service-Name':  Configuration.ServiceName,
        'Service-Version': Configuration.ServiceVersion,
        'Service-Weight': Configuration.ServiceWeightVersion,  
        'Model-List-Request': Configuration.bIsSubNetwork,  
        'Models': json.dumps(self.subModels)      # 小網路模型信息 
    }
       self.input_json['inputs'][0]['file_name'] = file_path
       file_name = os.path.basename(file_path)
       self.input_json['inputs'][0]['dut_sn'] = os.path.splitext(file_name)[0]

       if ".jpg" == os.path.splitext(file_name)[1]:
          self.input_json['inputs'][0]['part_id'] = 1
       elif ".jpeg" == os.path.splitext(file_name)[1]:
          self.input_json['inputs'][0]['part_id'] = 2

       im = cv2.imread(file_path)    
       x = im.shape[1]  
       y = im.shape[0]
       self.input_json['inputs'][0]['height'] = y
       self.input_json['inputs'][0]['width'] = x

       myfiles = [
            ('input_json', ('input_json', json.dumps(self.input_json), 'application/json')),                
            (file_path, (file_path, open(file_path, 'rb')))
        ]
       return requests.post(Configuration.CambrianServer, headers=model_info_headers, files=myfiles,timeout=Configuration.TimeOut).json()
    
class LocalPrediction():

  def __init__(self,tool):
     self.tool = tool
     self.input_json = {
			'dut_sn': '',
			'file_name': '',
			'station_id': Configuration.ServiceCallerID,
			'sub_model':Configuration.bIsSubNetwork,
			'sub_model_url': "",
			'client_ip':get_local_ip(tool,Configuration.LocalServerIp),
            'upload_sfis':'True'
      }
     self.__connect(Configuration.LocalServerRetryTimes)
     self.session = requests.Session()
    #  retry = Retry(
    #     total=Configuration.LocalServerRetryTimes,  # 最大重试次数
    #     backoff_factor=Configuration.BackoffFactor, # 重试间隔时间的基数
    #  )
     self.session.mount('http://', LocalHostAdapter(self.input_json['client_ip']))

  def __connect(self,retry_times):
    socket_up = None
    socket_down = None
    for i in range(retry_times):
        try:
            socket_up = socket.create_connection((Configuration.LocalServerIp,Configuration.LocalServerPortUp), 2)
            socket_down = socket.create_connection((Configuration.LocalServerIp,Configuration.LocalServerPortDown), 2)
            if  socket_up and socket_down:
                self.tool.print(f"与服务器 {Configuration.LocalServerIp} 端口号 ({Configuration.LocalServerPortUp},{Configuration.LocalServerPortDown})建立通信成功!!!",True)
                break
        except Exception:
            self.tool.printError(f"与服务器 {Configuration.LocalServerIp} 端口号 ({Configuration.LocalServerPortUp},{Configuration.LocalServerPortDown})建立通信失败!!!")
            if i == retry_times - 1:
                raise
        finally:
            if not socket_up is None:
                socket_up.shutdown(socket.SHUT_RDWR)
                socket_up.close()
            if not socket_down is None:
                socket_down.shutdown(socket.SHUT_RDWR)
                socket_down.close()
            time.sleep(0.1)

  def predict(self,file_path,upload_sfis):
     self.input_json['upload_sfis'] = upload_sfis
     file_name = os.path.basename(file_path)
     sn_and_ext = os.path.splitext(file_name)
     sn = sn_and_ext[0]
     extension = sn_and_ext[1]
     self.input_json['dut_sn'] = sn
     self.input_json['file_name'] = file_name
     myfiles = [
        (file_name,(file_name,open(file_path,'rb'))),
        ('input_json',('input_json',json.dumps(self.input_json),'application/json'))
     ]
     if extension in (".jpg",'.JPG'):
        Url = Configuration.UpImagePredictionUrl
        self.input_json['sub_model_url'] = Configuration.UpImagePredictionSubURL
        self.input_json['upload_sfis'] = 'False'
     elif extension in (".jpeg",".JPEG"):
        Url = Configuration.DownImagePredictionUrl
        self.input_json['sub_model_url'] = Configuration.DownImagePredictionSubURL
     return self.session.post(Url, headers={}, files=myfiles,timeout=Configuration.TimeOut).json()

class BackUpServer():
    def __init__(self,tool):
     self.tool = tool
     self.input_json = {
			'dut_sn': '',
			'station_id': Configuration.ServiceCallerID,
      }
     self.__connect()
     self.session = requests.Session()
     self.session.mount('http://', LocalHostAdapter(get_local_ip(tool,Configuration.BackUpServerIp)))
     
  
    def upload(self,sn):
        self.input_json['dut_sn'] = sn
        return self.session.post(Configuration.BackUpServerIpUploadUrl, headers={},data=json.dumps(self.input_json),timeout=10).json()

    def __connect(self):
       socket_connect = None
       try:
            socket_connect = socket.create_connection((Configuration.BackUpServerIp,Configuration.BackUpServerIpPort), 2)
            if socket_connect:
                self.tool.print(f"与服务器 {Configuration.BackUpServerIp} 端口号 ({Configuration.BackUpServerIpPort})建立通信成功!!!",True)
       except Exception :
            self.tool.printError(f"与服务器 {Configuration.BackUpServerIp} 端口号 ({Configuration.BackUpServerIpPort}建立通信失败!!!")
            raise 
       finally:
        if not socket_connect is None:
                socket_connect.shutdown(socket.SHUT_RDWR)
                socket_connect.close()