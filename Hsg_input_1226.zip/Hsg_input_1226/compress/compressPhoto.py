from PIL import Image
import json
import glob
def compress_image(input_path,output_path,quality):
    img=Image.open(input_path)
    if img.format == "JPEG" or img .format == "JPG":
        img.save(output_path,img.format,quality =quality,optimize=True)
    else:
        raise Exception("图片格式不是.jpg或.jpeg")


if __name__=="__main__":
    image1list=glob.glob("./Image1/*.jpg")
    image2list=glob.glob("./Image2/*.jpeg")
    print("Image1 中 jpg 文件数量为 {},Image2 中 jpeg 文件数量为 {}".format(len(image1list),len(image2list)))
    with open('setting.json','r') as st:
        setting=json.load(st)
    upQuality=setting['qualityUP']
    downQuality=setting['qualityDown']
    img1Num=0
    img2Num=0
    for itemi in image1list:
        try:
            compress_image(itemi,itemi,upQuality)
            print("{}压缩成功！!".format(itemi))
            img1Num+=1
        except Exception as e:
            print(e)
    for itemi in image2list:
        try:
            compress_image(itemi,itemi,downQuality)
            print("{}压缩成功！!".format(itemi))
            img2Num+=1
        except Exception as e:
            print(e)
    print("压缩完成\n jpg 图片压缩成功 {}张,失败{},jpeg 图片压缩成功 {}张,失败{}".
    format(img1Num,len(image1list)-img1Num,img2Num,len(image2list)-img2Num))
