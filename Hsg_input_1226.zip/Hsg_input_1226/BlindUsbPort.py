import os
os.system('./USB.sh')
with open('USB.txt','r') as data:
    Res=data.read()
Reslist=Res.split('>')
Reslist=Reslist[1:len(Reslist):2]
Map={}
for i in range(0,3):
    tmp=Reslist[i].split('/')
    port=tmp[8]
    tty=tmp[9]
    Map[port]=tty
plcPort=Map['1-8.4:1.0']
uplightPort=Map['1-8.3:1.0']
downlightPort=Map['1-8.2:1.0']
    
