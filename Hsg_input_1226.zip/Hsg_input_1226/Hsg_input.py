
import gc
import time,threading,atexit

from modbus_tk import modbus_rtu
from RS232Controller import serial
from watchdog.observers import Observer


from HikvisionClass import HikvisionCamera,Device
from BarcodeScanner import BarcodeScanner
from record import HistoryRecord,TableRecord
from dashboard import DashboardApp
from myWatchDog import BackUpHandler, MyHandler,ImageHandler
from configuration import Configuration,tool
from Cosmetic import Cosmetic


def clean_resorces(cam = None,cam2 = None,scanner = None,plc = None,serial_port = None,session = None,backup_session = None,three_color_light = None,observer = None):
        try:
            if not cam is None:
                cam.close_camera()
            if not cam2 is None:
                cam2.close_camera()
            if not scanner is None:
                scanner.closeScanner()
            if not plc is None:
                plc.close()
            if (not serial_port is None) and serial_port.is_open:
                serial_port.close()
            if (not three_color_light is None) and three_color_light.is_open:
                three_color_light.close()
            if not session is None:
                session.close()
            if not backup_session is None:
                backup_session.close()
            if (not observer is None) and observer.is_alive():
                observer.stop()
                observer.join()
        except Exception as e:
            tool.printError(f"退出异常!!! {e}")
        finally:
            tool.print("程序已退出!!!",True)
            gc.collect()



if __name__=='__main__':

    three_color_light = None
    serial_port = None
    Plc = None
    Scanner = None
    Cam1 = None
    Cam2 = None
    nitialization_successful = True
    try:
        if '' != Configuration.ThreeColorLightSerial:
            three_color_light = serial.Serial(port=Configuration.ThreeColorLightSerial,baudrate=Configuration.ThreeColorLightBaudrate,
                                            bytesize=Configuration.ThreeColorLightBytesize,
            parity=Configuration.ThreeColorLightParity,stopbits=Configuration.ThreeColorLightStopbits)
    except Exception as e:
        tool.printWarning('三色灯连接失败:{}'.format(e))
    try:
        
        camera_list = Device(tool).create_cameras()
        if (not Configuration.UpCameraIp in camera_list )or (not Configuration.DownCameraIp in camera_list):
            raise Exception("相机IP设置不一致!!!")

        Cam1=HikvisionCamera(tool,camera_list[Configuration.UpCameraIp])

        while not ((not Cam1 is None) and (Cam1.ready == True)):
            time.sleep(0.25)

        Cam2=HikvisionCamera(tool,camera_list[Configuration.DownCameraIp])

        while not ((not Cam2 is None) and (Cam2.ready == True)):
            time.sleep(0.25)

        Scanner=BarcodeScanner(Configuration.BarcodeScannerIp,Configuration.BarcodeScannerPort,tool)

        if '' != Configuration.PlcSerial:
            serial_port = serial.Serial(port=Configuration.PlcSerial,baudrate=Configuration.PlcBaudrate,bytesize=Configuration.PlcBytesize,
                                    parity=Configuration.PlcParity,stopbits=Configuration.PlcStopbits)
            Plc=modbus_rtu.RtuMaster(serial_port)
            Plc.set_timeout(timeout_in_sec = Configuration.PlcTimeout)
        else:
            tool.printError('获取PLC端口为空!!!')
            nitialization_successful = False
        
    except Exception as e:
        tool.printError('硬件连接失败:{}'.format(e))
        nitialization_successful = False
    
    try:
        session = None
        backup_session = None
        observer = None
        thread_event = threading.Event()
        if nitialization_successful:
            observer = Observer()
            event_handler = MyHandler(tool,TableRecord(),three_color_light)
            if not event_handler.predictior is None:
                session = event_handler.predictior.session
            if not event_handler.backupserver is None:
                backup_session = event_handler.backupserver.session
            backup_handler = BackUpHandler(tool)
            image_handler = ImageHandler(tool)
            observer.schedule(event_handler, Configuration.DataSetDir, recursive=True)
            observer.schedule(image_handler,Configuration.ImageUpDir)
            observer.schedule(image_handler,Configuration.ImageDownDir)
            observer.setDaemon = True
            reoload = threading.Thread(target=event_handler.reupload,daemon=True)
            Cos=Cosmetic(Plc,tool)
            scan_code_thread = threading.Thread(target=Cos.scan_code,args=(Scanner,thread_event),daemon=True)
            take_image_up_thread = threading.Thread(target=Cos.take_image_up,args=(Cam1,thread_event),daemon=True)
            take_image_down_thread = threading.Thread(target=Cos.take_image_down,args=(Cam2,thread_event),daemon=True)
            monitor_reset_button_thread = threading.Thread(target=Cos.monitor_reset_button,args=(thread_event,),daemon=True)

            dashboard = DashboardApp(HistoryRecord())

            scan_code_thread.start()
            take_image_up_thread.start()
            take_image_down_thread.start()
            monitor_reset_button_thread.start()
            if not three_color_light is None:
                triple_color_light_thread = threading.Thread(target=Cos.control_triple_color_light,args=(three_color_light,),daemon=True)
                triple_color_light_thread.start()
            reoload.start()
            observer.start()
            tool.print(f'Starting to watch {Configuration.DataSetDir},{Configuration.ImageUpDir} and {Configuration.ImageDownDir} for file system events...',True)
            dashboard.run()
    except Exception as e:
        tool.printError(f"程序运行异常 {e}")
    finally:
        atexit.register(clean_resorces,Cam1,Cam2,Scanner,Plc,serial_port,session,backup_session,three_color_light,observer)