import re
from collections import defaultdict
from datetime import datetime
import matplotlib.pyplot as plt

# 定义日志文件路径
log_file_path = 'RunningLog2024-08-29.log'
sortTime = defaultdict(list)
InfoSN = defaultdict(list)
# 打开并读取日志文件
with open(log_file_path, 'r', encoding='utf-8') as file:
    for line in file.readlines():
        # 按时间存储动作和信息
        match = re.match(r'\[(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})\]\[(\w+)\] (\S+) (.*)', line)
        if match:
            date = match.group(1)
            time = match.group(2)
            level = match.group(3)
            action = match.group(4)
            message = match.group(5)
            # print(f'Date: {date}, Time: {time}, Level: {level}, action: {action}, Message: {message}')
            sortTime[date+" "+time].append(action + " "+message)
            if ":" in message:
                InfoSN[message.split(":")[1][1:]].append(date+" "+time+" "+message)
            elif "named" in message:
                InfoSN[message.split("named")[1][1:]].append(date+" "+time+" "+action+" "+message)

# with open("2024-08-16.log",'w',encoding='utf-8') as fl:
#     for time,info in sortTime.items():
#         fl.write(f"datetime is {time}\n[")
#         fl.write("\n")
#         for value in info :
#             fl.write(f"Info is {value}\n")
#         fl.write("]\n")

def dt_list(dt):
    return datetime.strptime(dt,"%Y-%m-%d %H:%M:%S").timestamp()

lessEqual10 = []
lessEqual15 = []
lessEqual20 = []
lessEqual25 = []
gt25 = []

timeCord = []
for Sn,info in InfoSN.items():
    tempTime = {}
    if len(info) == 3:
        tili = []
        for value in info :
            result=re.match(r'(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})', value)
            if result:
                tili.append(result.group(0))
        tempTime[Sn] = tili
        tili_sort = sorted(tili,key=lambda dati:dt_list(dati))
        timeCord.append(tempTime)
        if len(tili_sort) >= 2:
            diff=(datetime.strptime(tili_sort[-1],"%Y-%m-%d %H:%M:%S") - datetime.strptime(tili_sort[0],"%Y-%m-%d %H:%M:%S")).seconds
            if diff<= 10:
                lessEqual10.append(diff)
            elif diff <= 15:
                lessEqual15.append(diff)
            elif diff <= 20:
                lessEqual20.append(diff)
            elif diff <= 25:
                lessEqual25.append(diff)
            else:
                gt25.append(diff)
            # if diff > 100:
            #     print(info)
            info.append("Max diff is {}s".format(diff))



# 设置全局字体为支持中文的字体，例如SimHei（黑体）
plt.rcParams['font.sans-serif'] = 'SimHei'
# 分组名称
labels = ['1s-10s', '11s-15s', '16s-20s', '21s-25s','>26s']
# 分组数据
data = [len(lessEqual10), len(lessEqual15), len(lessEqual20), len(lessEqual25),len(gt25)]
# 绘制饼图
plt.pie(data, labels=labels,autopct='%1.1f%%',colors=['green', 'yellow', 'blue','orange', 'red'])
plt.axis('equal') # 保持图形为正圆形
plt.title('Hsg-Input时间差分布图')
# 显示中文标签在饼图的中心
# plt.text(0, 0, ha='center', va='center', fontproperties='SimHei', fontsize=12, weight='bold', color='black')
# plt.show()
# print(timeCord)
Max_time = set()
flag = True
for exInd in range(0,len(timeCord)-1):
    for inInd in range(exInd+1,len(timeCord)):
        if list(timeCord[inInd].values())[0][1] > list(timeCord[exInd].values())[0][1] and list(timeCord[inInd].values())[0][1] < list(timeCord[exInd].values())[0][2]:
            for downTime in range(inInd+1,len(timeCord)):
                if list(timeCord[downTime].values())[0][1] > list(timeCord[exInd].values())[0][1] and list(timeCord[downTime].values())[0][1] < list(timeCord[exInd].values())[0][2]:
                    Max_time.add(list(timeCord[exInd].keys())[0])
                    flag = False
                    break
            flag = True
        if flag:
            if list(timeCord[inInd].values())[0][2] > list(timeCord[exInd].values())[0][1] and list(timeCord[inInd].values())[0][2] < list(timeCord[exInd].values())[0][2]:
                for downTime in range(inInd+1,len(timeCord)):
                    if list(timeCord[downTime].values())[0][2] > list(timeCord[exInd].values())[0][1] and list(timeCord[downTime].values())[0][2] < list(timeCord[exInd].values())[0][2]:
                        Max_time.add(list(timeCord[exInd].keys())[0])
                        break

with open("failedSn_2024-08-29.log",'w',encoding='utf-8') as fd:
    for item in Max_time:
        fd.write(f"{item}\n")
# print(Max_time)
# with open("paraLogBySn_2024-08-16.log",'w',encoding='utf-8') as fl:
#     for sn,info in InfoSN.items():
#         if len(info) >3 :
#             fl.write(f"sn is {sn}\n[")
#             fl.write("\n")
#             for value in info :
#                 fl.write(f"Info is {value}\n")
#             fl.write("]\n")
