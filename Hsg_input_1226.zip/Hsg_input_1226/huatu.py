# import dash
# from dash import dcc, html,Input,Output
# import plotly.graph_objs as go
# import numpy as np
# import random

# app = dash.Dash(__name__)

# # 初始化数据
# x_data = list(range(0,23))
# y_data = [random.randint(0, 100) for _ in range(24)]

# app.layout = html.Div([
#     dcc.Graph(id='live-update-graph'),
#     dcc.Interval(
#         id='interval-component',
#         interval=1*1000*5,  # 每秒更新一次
#         n_intervals=0
#     )
# ])

# @app.callback(
#         Output('live-update-graph', 'figure'),
#         Input('interval-component', 'n_intervals')
# )
# def update_graph(n):
#     y_data.append(random.randint(0, 100))  # 随机生成新的数据量
#     y_data.pop(0)  # 移除最旧的数据
#     figure = go.Figure()
#     figure.add_trace(go.Scatter(x=x_data, y=y_data, mode='lines+markers'))
#     figure.update_layout(title='每小时数据量动态显示', 
#                          xaxis_title='HOUR', 
#                          yaxis_title='UPH',
#                          xaxis=dict(tickmode='linear', dtick=1))
#     return figure

# if __name__ == '__main__':
#     app.run_server(debug=True)

import datetime
import os
import threading
import time

class OLP():
    def log(self,msg):
        pid = os.getpid()
        tid = threading.current_thread().ident
        print(f"进程:[{pid}]线程:[{tid}]{msg}")


    def add(self,x, y):
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"现在的时间是:{now}")
        print(f"执行加法:{x} + {y} = {x + y}")
        time.sleep(3)
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"现在的时间是:{now},结束加法运算")
        return x + y


if __name__ == '__main__':
    print("我是主线程")
    a= OLP()
    t1 = threading.Thread(target=a.add, args=(1, 2))
    t2 = threading.Thread(target=a.add, args=(3, 4))
    t1.start()
    t2.start()
    print("主线程完事")

