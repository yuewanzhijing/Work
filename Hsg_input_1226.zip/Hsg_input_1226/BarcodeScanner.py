from socket import socket, AF_INET, SOCK_STREAM,SHUT_RDWR


class BarcodeScanner:
    def __init__(self, scannerHost, scannerPort, Tool):
        try:
            self.scannerHost = scannerHost
            self.scannerPort = int(scannerPort)
            self.Tool = Tool
            self.tcp=socket(AF_INET, SOCK_STREAM)
            self.tcp.connect((self.scannerHost,self.scannerPort))
            self.Tool.print(f"[BarcodeScanner] {self.scannerHost}:{self.scannerPort} 扫码器连接成功!!!", writeLog=True)
        except Exception as e:
            self.Tool.printError(f'扫码器连接失败!!! {self.scannerHost}:{self.scannerPort} {e}')
            raise

    def getBarcode(self):
        buf = 1024
        barcode = "NR"  # 默认初始化为 "NR"
        try:
                self.Tool.print("[BarcodeScanner] 發送請求...", writeLog=True)
                self.tcp.send("T".encode())
                barcode = self.tcp.recv(buf).decode('utf-8')
                if barcode == "NR":
                    self.Tool.printError(f"[BarcodeScanner] 條碼讀取失敗: {barcode}")
                else:
                    self.Tool.print(f"[BarcodeScanner] 讀取到條碼: {barcode}", writeLog=True)
        except Exception as e:
            self.Tool.printError(
                f'读码失败!!! {self.scannerHost}:{self.scannerPort} {e}')
            raise

        return barcode

    def closeScanner(self):
        self.tcp.shutdown(SHUT_RDWR)
        self.tcp.close()
        
