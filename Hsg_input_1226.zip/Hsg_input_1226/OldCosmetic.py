
    
















from RS232Controller import *
import modbus_tk.defines as cst
from BarcodeScanner import *
from HikvisionClass import *
import cv2
import time
from PIL import Image
from datetime import datetime,timedelta
from globals import *
from configuration import Configuration
from record import HistoryRecord

class Cosmetic:
    
    Barcode=[]
    codeName1=None
    codeName2=[]
    Img1=None
    Img2=None
    
    per_hour_uph_state = {}
    per_hour_uph_complete = 0

    UPH_LAST_HOUR = 0
    SCAN_RATE_LAST_HOUR = 0.0
    
    
    def __init__(self,Plc,Tool):
        self.plc=Plc
        self.tool = Tool

    def __compress_image(self,input_path,output_path,quality):
        img=Image.open(input_path)
        if img.format == "JPEG" or img .format == "JPG":
            img.save(output_path,img.format,quality =quality,optimize=True)
        else:
            self.tool.printError("图片格式不是.jpg或.jpeg",True)
            raise Exception("图片格式有误,无法使用此方法压缩")

    def scan_code(self,scanner):
        M0=2048
        M1=2049
        M2=2050
        times=0
        hour_successes = 0
        one_hour_time = 0
        master=self.plc
        histry_record = HistoryRecord()
        try:
            while True:
                while ((master.execute(slave = 1,function_code = cst.READ_COILS,starting_address = M0,quantity_of_x=1))[0]!=1):
                    time.sleep(0.1)
                self.tool.print(f"Receved permissoin sign to scan {times + 1}",True)
                if times == 0:
                    one_hour_later = datetime.now().replace(minute=0,second=0) + timedelta(hours=1)
                if datetime.now() > one_hour_later:
                    SCAN_TIME.append(one_hour_later)
                    one_hour_success_rate = 0
                    if one_hour_time > 0:
                        one_hour_success_rate = round(hour_successes / one_hour_time,2) * 100
                    SCAN_RATE_PER_HOUR.append(one_hour_success_rate)
                    Cosmetic.SCAN_RATE_LAST_HOUR = one_hour_success_rate

                    UPH_TIME.append(one_hour_later)
                    UPH_PER_HOUR.append(Cosmetic.per_hour_uph_complete)
                    Cosmetic.UPH_LAST_HOUR = Cosmetic.per_hour_uph_complete

                    string_format = one_hour_later.strftime("%Y-%m-%d_%H:%M:%S")
                    histry_record.write_scan_rate({string_format:one_hour_success_rate})
                    histry_record.write_uph({string_format:Cosmetic.per_hour_uph_complete})
                    


                    Cosmetic.per_hour_uph_complete = 0
                    hour_successes = 0
                    one_hour_time = 0
                    one_hour_later = one_hour_later + timedelta(hours=1)

                
                
                code=scanner.getBarcode()
                if ("NR"!=code):
                    if len(Cosmetic.Barcode) == 1 and code == Cosmetic.Barcode[0]:
                        continue
                    Cosmetic.Barcode.append(code)
                    master.execute(1,cst.WRITE_SINGLE_COIL,M1,quantity_of_x=1,output_value=1)
                    self.tool.print(f"sended sign to PLC that scaned {times + 1} has done",True)
                    hour_successes = hour_successes + 1
                    Cosmetic.per_hour_uph_state[code] = 1
                else:
                    master.execute(1,cst.WRITE_SINGLE_COIL,M2,quantity_of_x=1,output_value=1)
                    self.tool.printError(f"sended sign to PLC that scaned {times + 1} has failed",True)
                one_hour_time = one_hour_time + 1
                times=times+1
        except Exception as e:
            self.tool.printError(f"程序运行异常!!! :{e}")

    def take_image_up(self,CameraUp):
        M10=2058
        M11=2059
        M12=2060
        master=self.plc
        quality=Configuration.UpImageQuality
        times=1
        try:
            while True:
                    while ((master.execute(slave = 1,function_code = cst.READ_COILS,starting_address = M10,quantity_of_x=1))[0]!=1):
                        time.sleep(0.1)
                    self.tool.print(f"Receved permissoin sign {times} to take a photo up",True)
                    while (len(Cosmetic.Barcode)==0):
                        time.sleep(0.1)
                    Cosmetic.codeName1 = Cosmetic.Barcode.pop(0)
                    Cosmetic.codeName2.append(Cosmetic.codeName1)
                    Cosmetic.Img1=CameraUp.get_image()
                    if (not Cosmetic.Img1 is None):
                        cv2.imwrite(f"{Configuration.DataSetDir}/{Cosmetic.codeName1}.jpg",Cosmetic.Img1,[int(cv2.IMWRITE_JPEG_QUALITY),quality])
                        self.tool.print(f"Up-camera takes photo {times} successfully,named {Cosmetic.codeName1}.jpg",writeLog=True)
                        master.execute(1,cst.WRITE_SINGLE_COIL,M11,quantity_of_x=1,output_value=1)
                        self.tool.print(f"sended sign {times} to PLC that Up-camera takes a photo has done",True)
                        if Cosmetic.codeName1 in Cosmetic.per_hour_uph_state:
                            Cosmetic.per_hour_uph_state[Cosmetic.codeName1] = Cosmetic.per_hour_uph_state[Cosmetic.codeName1] + 1
                    else:
                        self.tool.printError(f"Up-camera takes photo {times} failed,named {Cosmetic.codeName1}.jpg",writeLog=True)
                        master.execute(1,cst.WRITE_SINGLE_COIL,M12,quantity_of_x=1,output_value=1)
                        self.tool.printError(f"sended sign {times} to PLC that Up-camera takes a photo has failed",True)
                    times=times+1
        except Exception as e:
            self.tool.printError(f"程序运行异常!!! :{e}")
       
    def take_image_down(self,CameraDown):
        M20=2068
        M21=2069
        M22=2070
        master=self.plc
        quality=Configuration.DownImageQuality
        times=1
        try:
            while True:
                    while ((master.execute(slave = 1,function_code = cst.READ_COILS,starting_address = M20,quantity_of_x=1))[0]!=1):
                        time.sleep(0.1)
                    self.tool.print(f"Receved permissoin sign {times} to take a photo down",True)
                    while len(Cosmetic.codeName2) == 0:
                        time.sleep(0.25)
                    time.sleep(Configuration.delayTime)
                    Cosmetic.Img2=CameraDown.get_image()
                    if (not Cosmetic.Img2 is None):
                        cv2.imwrite(f"{Configuration.DataSetDir}/{Cosmetic.codeName2[0]}.jpeg",Cosmetic.Img2,[int(cv2.IMWRITE_JPEG_QUALITY),quality])
                        self.tool.print(f"Down-camera takes photo {times} successfully,named {Cosmetic.codeName2[0]}.jpeg",writeLog=True)
                        if Cosmetic.codeName2[0] in Cosmetic.per_hour_uph_state and Cosmetic.per_hour_uph_state[Cosmetic.codeName2[0]] == 2:
                            Cosmetic.per_hour_uph_complete = Cosmetic.per_hour_uph_complete + 1
                            del Cosmetic.per_hour_uph_state[Cosmetic.codeName2[0]]
                        Cosmetic.codeName2.remove(Cosmetic.codeName2[0])
                        master.execute(1,cst.WRITE_SINGLE_COIL,M21,quantity_of_x=1,output_value=1)
                        self.tool.print(f"sended sign {times} to PLC that Down-camera takes a photo has done",True)
                    else:
                        self.tool.printError(f"Down-camera takes photo {times} failed,named {Cosmetic.codeName2[0]}.jpeg",writeLog=True)
                        Cosmetic.codeName2.remove(Cosmetic.codeName2[0])
                        master.execute(1,cst.WRITE_SINGLE_COIL,M22,quantity_of_x=1,output_value=1)
                        self.tool.printError(f"sended sign {times} to PLC that Down-camera takes a photo has failed",True)
                    times=times+1
        except Exception as e:
            self.tool.printError(f"程序运行异常!!! :{e}")
    
                


    
    def recover(self):
        M197=2245
        M198=2246
        M199=2247
        M102=2150
        master=self.plc
        master.set_timeout(1)
        try :
            master.execute(1,cst.WRITE_SINGLE_COIL,M197,quantity_of_x=1,output_value=1)
            self.tool.print('Stop button is pressed',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        time.sleep(0.5)
        try :
            master.execute(1,cst.WRITE_SINGLE_COIL,M197,quantity_of_x=1,output_value=0)
            self.tool.print('Stop button is released',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        time.sleep(0.25)
        try:
            master.execute(1,cst.WRITE_SINGLE_COIL,M199,quantity_of_x=1,output_value=1)
            self.tool.print('Recover button is pressed',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        try:
            master.execute(1,cst.WRITE_SINGLE_COIL,M199,quantity_of_x=1,output_value=0)
            self.tool.print('Recover button is released',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        try:
            Flag=master.execute(1,cst.READ_COILS,M102,quantity_of_x=1)
            self.tool.print('Plate rotates',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        while Flag[0]!=1:
            Flag=master.execute(1,cst.READ_COILS,M102,quantity_of_x=1)
            self.tool.print('Plate is rotating',writeLog=True)
        self.tool.print('Plate stoped',writeLog=True)
        try:
            master.execute(1,cst.WRITE_SINGLE_COIL,M198,quantity_of_x=1,output_value=1)
            self.tool.print('Start-button is pressed',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        try :
            master.execute(1,cst.WRITE_SINGLE_COIL,M198,quantity_of_x=1,output_value=0)
            self.tool.print('Start-button is released',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
    


