'''
@Auther: Melt_Min
@Author:Sun_Zhao
@Last Modify: 2024-10-16
@Usage: 相機調用
'''
# -- coding: utf-8 --
from datetime import datetime, timedelta
import sys
# import termios
import importlib
import numpy as np
import cv2
import time
import threading


MCC = None

class Device():
    def __init__(self,tool) -> None:
        self.Tool = tool
        if not "/opt/MVS/Samples/64/Python/MvImport" in sys.path:
            sys.path.append("/opt/MVS/Samples/64/Python/MvImport")
        global MCC
        try:
            MCC = importlib.import_module("MvCameraControl_class")
        except ImportError as e:
            self.Tool.printError(f"Error importing MvCameraControl_class: {e}")
            sys.exit()

    def create_cameras(self):
        camera_info = {}
        SDKVersion = MCC.MvCamera.MV_CC_GetSDKVersion()
        self.Tool.print("SDKVersion[0x%x]" % SDKVersion,True)

        deviceList = MCC.MV_CC_DEVICE_INFO_LIST()
        tlayerType = MCC.MV_GIGE_DEVICE | MCC.MV_USB_DEVICE

        # ch:枚举设备 | en:Enum device
        ret = MCC.MvCamera.MV_CC_EnumDevices(tlayerType, deviceList)
        if ret != 0:
            self.Tool.printError("Enum devices fail! ret[0x%x]" % ret,False)
            raise Exception("Enum devices fail! ret[0x%x]" % ret)

        if deviceList.nDeviceNum == 0:
            self.Tool.printError("Find no device!",False)
            raise Exception("Find no device!")

        self.Tool.print("Find %d devices!" % deviceList.nDeviceNum,True)
        for i in range(0, deviceList.nDeviceNum):
            mvcc_dev_info = MCC.cast(deviceList.pDeviceInfo[i], MCC.POINTER(MCC.MV_CC_DEVICE_INFO)).contents
            if mvcc_dev_info.nTLayerType == MCC.MV_GIGE_DEVICE:
                self.Tool.print("Gige device: [%d]" % i,True)
                byteModeName = bytes(mvcc_dev_info.SpecialInfo.stGigEInfo.chModelName)
                strModeName = "".join(
                    chr(byteinfo) for byteinfo in byteModeName if 0!= byteinfo
                )
                
                self.Tool.print("Device model name: %s" % strModeName,True)

                nip1 = (
                    (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0xff000000) >> 24)
                nip2 = (
                    (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x00ff0000) >> 16)
                nip3 = (
                    (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x0000ff00) >> 8)
                nip4 = (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x000000ff)
                self.Tool.print("Current ip: %d.%d.%d.%d" %(nip1, nip2, nip3, nip4),True)
                current_ip = "{}.{}.{}.{}".format(nip1, nip2, nip3, nip4)

                # ch:创建相机实例 | en:Creat Camera Object
                cam = MCC.MvCamera()
                self.Tool.print(f'create camera {i} successfully',True)
                # ch:选择设备并创建句柄 | en:Select device and create handle
            
                stDeviceList = MCC.cast(deviceList.pDeviceInfo[int(i)], MCC.POINTER(MCC.MV_CC_DEVICE_INFO)).contents
                ret = cam.MV_CC_CreateHandle(stDeviceList)
                if ret != 0:
                    self.Tool.printError("[Camera] 相機創建句柄失敗! ret[0x%x]" % ret,False)
                    raise Exception("[Camera] 相機創建句柄失敗! ret[0x%x]" % ret)
                camera_info[current_ip] = {"camera":cam,"stDeviceList":stDeviceList,"ip":current_ip}

        return camera_info

class HikvisionCamera(object):
    def __init__(self, tool,Info):
        self.Tool = tool
        self.cam = Info['camera']
        self.stDeviceList = Info['stDeviceList']
        self.image = None
        self.read_finished = False
        self.__new_thread(Info['ip'])
        self.ready = False

    def __new_thread(self,ip):
        self.thread = threading.Thread(target=self.__open_camera, args=(ip,),daemon=True)
        self.thread.start()

    def __FrameInfoCallBack(self):
        winfun_ctype = MCC.CFUNCTYPE
        stFrameInfo = MCC.POINTER(MCC.MV_FRAME_OUT_INFO_EX)
        pData = MCC.POINTER(MCC.c_ubyte)
        return winfun_ctype(None, pData, stFrameInfo, MCC.c_void_p)

    def __callback(self, pData, pFrameInfo, pUser):
        stFrameInfo = MCC.cast(pFrameInfo, MCC.POINTER(MCC.MV_FRAME_OUT_INFO_EX)).contents
        stConvertParam = MCC.MV_SAVE_IMAGE_PARAM_EX()
        try:
                bmp_buf = (MCC.c_ubyte * (stFrameInfo.nWidth * stFrameInfo.nHeight * 3 + 1024))()
        except MemoryError:
                self.Tool.printError("Memory allocation failed")
                self.image = None
                self.read_finished = True
        else:
                MCC.memset(MCC.byref(stConvertParam), 0, MCC.sizeof(MCC.MV_SAVE_IMAGE_PARAM_EX))
                stConvertParam.enImageType = MCC.MV_Image_Bmp
                stConvertParam.enPixelType = stFrameInfo.enPixelType
                stConvertParam.nBufferSize = stFrameInfo.nWidth * stFrameInfo.nHeight * 3 + 1024
                stConvertParam.nWidth = stFrameInfo.nWidth
                stConvertParam.nHeight = stFrameInfo.nHeight
                stConvertParam.pData = pData
                stConvertParam.nDataLen = stFrameInfo.nWidth * stFrameInfo.nHeight * 3 + 1024
                stConvertParam.pImageBuffer = bmp_buf
                ret = self.cam.MV_CC_SaveImageEx2(stConvertParam)
                if ret!= 0:
                    self.Tool.printError("failed in MV_CC_SaveImage,nRet[0x%x]" % ret)
                    self.image = None
                    self.read_finished = True

                else:
                    img_buff = (MCC.c_ubyte * stConvertParam.nDataLen)()
                    MCC.memmove(MCC.byref(img_buff),stConvertParam.pImageBuffer, stConvertParam.nDataLen)
                    nparr = np.frombuffer(img_buff, np.uint8)
                    self.image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                    five_sec = datetime.now()+timedelta(seconds=5)
                    while self.image is not None and self.image.size != 0:
                        if datetime.now() > five_sec:
                            self.Tool.printError("图像解码失败!!!")
                            self.image = None
                        self.read_finished = True
                        break

    def __open_camera(self,camera_ip):
        # ch:打开设备 | en:Open device

        res = self.cam.MV_CC_OpenDevice(MCC.MV_ACCESS_Exclusive, 0)
        if res != 0:
            self.Tool.printError("[Camera] 相機%s打開失敗! ret[0x%x]" % (camera_ip,res),False)
            ret = self.cam.MV_CC_DestroyHandle()
            if ret != 0:
                    self.Tool.printError("[Camera] 銷毀句柄失敗! ret[0x%x]" % ret,False)
                    raise Exception("[Camera] 相机%s打开失败 ret[0x%x] 銷毀句柄失敗! ret[0x%x]" % (camera_ip,res,ret))
            raise Exception("[Camera] 相機%s打開失敗! ret[0x%x]" % (camera_ip,res))
        else:
            self.Tool.print('camera %s open Successfully' %camera_ip,True)
        # ch:探测网络最佳包大小(只对GigE相机有效) | en:Detection network optimal package size(It only works for the GigE camera)
        if self.stDeviceList.nTLayerType == MCC.MV_GIGE_DEVICE:
            nPacketSize = self.cam.MV_CC_GetOptimalPacketSize()
            if int(nPacketSize) > 0:
                ret = self.cam.MV_CC_SetIntValue("GevSCPSPacketSize", nPacketSize)
                if ret != 0:
                    self.Tool.printWarning(
                        "[Camera] 相機设置最佳網絡包失敗! ret[0x%x]" % ret)
            else:
                self.Tool.printWarning(
                    "[Camera] 相機獲取最佳網絡包失敗! ret[0x%x]" % nPacketSize)

        ret = self.cam.MV_CC_SetEnumValue("AcquisitionMode", MCC.MV_ACQ_MODE_CONTINUOUS)
        if ret != 0:
            self.Tool.printError("Set acquisition mode continuous fail! ret[0x%x]" % ret,False)
            raise Exception("Set acquisition mode continuous fail! ret[0x%x]" % ret)
        # ret = self.cam.MV_CC_SetEnumValue("TriggerMode", MCC.MV_TRIGGER_MODE_OFF)
        ret = self.cam.MV_CC_SetEnumValue("TriggerMode", MCC.MV_TRIGGER_MODE_ON)
        if ret != 0:
            self.Tool.printError("Set trigger mode on fail! ret[0x%x]" % ret,False)
            raise Exception("Set trigger mode on fail! ret[0x%x]" % ret)
        
        ret = self.cam.MV_CC_SetEnumValue("TriggerSource", MCC.MV_TRIGGER_SOURCE_SOFTWARE);
        if ret != 0:
            self.Tool.printError("Set trigger source software fail! nRet [0x%x]" % ret,False)
            raise Exception("Set trigger source software fail! nRet [0x%x]" % ret)

        # ch:注册抓图回调 | en:Register image callback
        
        CALL_BACK_FUN = self.__FrameInfoCallBack()(self.__callback)
        ret = self.cam.MV_CC_RegisterImageCallBackEx(CALL_BACK_FUN, None)
        if ret != 0:
            self.Tool.printError("[Camera] 相機註冊回調失敗! ret[0x%x]" % ret,False)
            raise Exception("[Camera] 相機註冊回調失敗! ret[0x%x]" % ret)

        ret = self.cam.MV_CC_StartGrabbing()
        if ret != 0:
            self.Tool.printError("[Camera] 相機開始取流失敗! ret[0x%x]" % ret,False)
            raise Exception("[Camera] 相機開始取流失敗! ret[0x%x]" % ret)

        self.Tool.print("[Camera %s] 相機運行中.." %camera_ip,True)
        self.ready = True
        while True:
            time.sleep(0.1)
            pass

    def close_camera(self):
        self.Tool.print("Close camera..",True)
        if self.cam is not None:
        # ch:停止取流 | en:Stop grab image
            try:
                ret = self.cam.MV_CC_StopGrabbing()
                if ret != 0:
                    self.Tool.printError("[Camera] 相機停止取流失敗! ret[0x%x]" % ret,False)
                    raise Exception("[Camera] 相機停止取流失敗! ret[0x%x]" % ret)

                # ch:关闭设备 | Close device
                ret = self.cam.MV_CC_CloseDevice()
                if ret != 0:
                    self.Tool.printError("[Camera] 设备關閉失敗! ret[0x%x]" % ret,False)
                    raise Exception("[Camera] 设备關閉失敗! ret[0x%x]" % ret)

                # ch:销毁句柄 | Destroy handle
                ret = self.cam.MV_CC_DestroyHandle()
                if ret != 0:
                    self.Tool.printError("[Camera] 銷毀句柄失敗! ret[0x%x]" % ret,False)
                    raise Exception("[Camera] 銷毀句柄失敗! ret[0x%x]" % ret)
            except Exception as e:
                self.Tool.printError(f"相机关闭失败 {e}")
                raise 

        self.Tool.print("[Camera] 關閉相機作業結束.",True)



    def get_image(self):
        while not self.ready:
            time.sleep(0.1)
        nRet = self.cam.MV_CC_SetCommandValue("TriggerSoftware")
        if 0 != nRet:
            self.Tool.printError("failed in TriggerSoftware[0x%x]" %nRet)
            return None
        else:
            while not self.read_finished:
                time.sleep(0.1)
            self.read_finished = False
            return self.image
