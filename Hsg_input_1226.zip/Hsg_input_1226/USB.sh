#!/bin/sh
ls -l /sys/class/tty/ttyUSB* > USB.txt