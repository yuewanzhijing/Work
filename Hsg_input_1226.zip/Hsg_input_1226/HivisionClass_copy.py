'''
@Auther: Melt_Min
@Last Modify: 2021-06-03
@Usage: 相機調用
'''
# -- coding: utf-8 --

from datetime import datetime
import sys
# import copy
# import termios

# from ctypes import *
import numpy as np
import cv2

import time
import threading
from Tool import Tool


MCC = None


def import_src_fun():
    global MCC
    MCC = __import__("MvCameraControl_class")


class HikvisionCamera(object):
    def __init__(self, tool,mvimport_src=None, config={}):
        if mvimport_src is None:
            if "/opt/MVS/Samples/64/Python/MvImport" not in sys.path:
                sys.path.append("/opt/MVS/Samples/64/Python/MvImport")
        else:
            sys.path.append(mvimport_src)
        import_src_fun()
        self.Tool = tool
        self.need_one_frame = False
        self.image = None
        self.stop_camera = False
        self.config = config
        self.__new_thread()


    def __new_thread(self):
        self.thread = threading.Thread(target=self.__open_camera, daemon=True)
        self.thread.start()

    def __FrameInfoCallBack(self):
        winfun_ctype = MCC.CFUNCTYPE
        stFrameInfo = MCC.POINTER(MCC.MV_FRAME_OUT_INFO_EX)
        pData = MCC.POINTER(MCC.c_ubyte)
        return winfun_ctype(None, pData, stFrameInfo, MCC.c_void_p)

    def __callback(self, pData, pFrameInfo, pUser):
        stFrameInfo = MCC.cast(pFrameInfo, MCC.POINTER(
            MCC.MV_FRAME_OUT_INFO_EX)).contents
        if self.need_one_frame == False:
            return False
        if stFrameInfo:
            self.need_one_frame = False
            stConvertParam = MCC.MV_SAVE_IMAGE_PARAM_EX()
            stConvertParam.nWidth = stFrameInfo.nWidth
            stConvertParam.nHeight = stFrameInfo.nHeight
            stConvertParam.pData = pData
            # stConvertParam.nDataLen = stFrameInfo.nFrameLen
            stConvertParam.enPixelType = stFrameInfo.enPixelType
            stConvertParam.nDataLen = stFrameInfo.nWidth * stFrameInfo.nHeight * 3 + 54
            stConvertParam.enImageType = MCC.MV_Image_Bmp
            bmpsize = stFrameInfo.nWidth * stFrameInfo.nHeight * 3 + 54
            stConvertParam.nBufferSize = bmpsize
            bmp_buf = (MCC.c_ubyte * bmpsize)()
            stConvertParam.pImageBuffer = bmp_buf

            ret = None
            for i in range(3):
                try:
                    ret = self.cam.MV_CC_SaveImageEx2(stConvertParam)
                    break
                except BaseException as e:
                    print(e)
                    self.Tool.printWarning(
                        "[Camera] Camera status error retry in 2 sec.")
                time.sleep(2)

            if ret == None:
                self.Tool.printError("[Camera] Camera connect error.")
                sys.exit()

            if ret != 0:
                self.Tool.printError(
                    "Save file executed failed0:! ret[0x%x]" % ret)
                sys.exit()

            img_buff = (MCC.c_ubyte * stConvertParam.nDataLen)()
            MCC.memmove(MCC.byref(img_buff),
                        stConvertParam.pImageBuffer, stConvertParam.nDataLen)
            nparr = np.frombuffer(img_buff, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            self.image = img
            self.need_one_frame = False

        else:
            self.Tool.printWarning("Get Image Fail, Retrying..")
            self.image = None
            self.need_one_frame = True

    def __open_camera(self):
        SDKVersion = MCC.MvCamera.MV_CC_GetSDKVersion()
        self.Tool.print("SDKVersion[0x%x]" % SDKVersion)

        deviceList = MCC.MV_CC_DEVICE_INFO_LIST()
        tlayerType = MCC.MV_GIGE_DEVICE | MCC.MV_USB_DEVICE

        # ch:枚举设备 | en:Enum device
        ret = MCC.MvCamera.MV_CC_EnumDevices(tlayerType, deviceList)
        if ret != 0:
            self.Tool.printError("Enum devices fail! ret[0x%x]" % ret)
            sys.exit()

        if deviceList.nDeviceNum == 0:
            self.Tool.printError("Find no device!")
            self.stop_camera = True
            return None

        self.Tool.print("Find %d devices!" % deviceList.nDeviceNum,True)
        for i in range(0, deviceList.nDeviceNum):
            mvcc_dev_info = MCC.cast(deviceList.pDeviceInfo[i], MCC.POINTER(
                MCC.MV_CC_DEVICE_INFO)).contents
            if mvcc_dev_info.nTLayerType == MCC.MV_GIGE_DEVICE:
                self.Tool.print("\nGige device: [%d]" % i,True)
                strModeName = ""
                for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chModelName:
                    strModeName = strModeName + chr(per)
                self.Tool.print("Device model name: %s" % strModeName)

                nip1 = (
                    (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0xff000000) >> 24)
                nip2 = (
                    (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x00ff0000) >> 16)
                nip3 = (
                    (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x0000ff00) >> 8)
                nip4 = (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x000000ff)
                self.Tool.print("Current ip: %d.%d.%d.%d" %(nip1, nip2, nip3, nip4),True)

                if self.config["IP"] == "{}.{}.{}.{}".format(nip1, nip2, nip3, nip4):
                    nConnectionNum = i
                    break
                elif self.config["IP"] == "{}.{}.{}.{}".format(nip1, nip2, nip3, nip4):
                    nConnectionNum = i
                    break
            # elif mvcc_dev_info.nTLayerType == MCC.MV_USB_DEVICE:
            #     self.Tool.print("\nU3v device: [%d]" % i)
            #     strModeName = ""
            #     for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chModelName:
            #         if per == 0:
            #             break
            #         strModeName = strModeName + chr(per)
            #     self.Tool.print("Device model name: %s" % strModeName)

            #     strSerialNumber = ""
            #     for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chSerialNumber:
            #         if per == 0:
            #             break
            #         strSerialNumber = strSerialNumber + chr(per)
            #     self.Tool.print("User serial number: %s" % strSerialNumber)
        # if deviceList.nDeviceNum > 1:
        #     self.Tool.print(f"Find {deviceList.nDeviceNum} camera device(s)")
        #     if self.config["IP"]=="10.64.58.5":
        #         nConnectionNum = 0
        #     elif self.config["IP"]=="10.64.57.5":
        #         nConnectionNum = 1
        if deviceList.nDeviceNum == 1 :
            self.Tool.printWarning((f"find {deviceList.nDeviceNum}  use camera index 0(default)"))
            nConnectionNum = 0
        
        # ch:创建相机实例 | en:Creat Camera Object
        cam = MCC.MvCamera()
        self.Tool.print('create camera successfully',True)
        # ch:选择设备并创建句柄 | en:Select device and create handle
        
        # else:
        #     nConnectionNum==0
        # nConnectionNum==0
        # if int(nConnectionNum) >= deviceList.nDeviceNum:
        #     self.Tool.printError("Intput error!")
        #     sys.exit()
        stDeviceList = MCC.cast(deviceList.pDeviceInfo[int(
            nConnectionNum)], MCC.POINTER(MCC.MV_CC_DEVICE_INFO)).contents
        ret = cam.MV_CC_CreateHandle(stDeviceList)
        if ret != 0:
            self.Tool.printError("[Camera] 相機創建句柄失敗! ret[0x%x]" % ret)
            sys.exit()
        # ch:打开设备 | en:Open device
        try:
            ret = cam.MV_CC_OpenDevice(MCC.MV_ACCESS_Exclusive, 0)
        except BaseException as e:
            self.Tool.printError(e)
        if ret != 0:
            self.Tool.printError("[Camera] 相機%d打開失敗! ret[0x%x]" % (nConnectionNum,ret))
            sys.exit()
        else:
            print('camera %d open Successfully' %nConnectionNum)
        # ch:探测网络最佳包大小(只对GigE相机有效) | en:Detection network optimal package size(It only works for the GigE camera)
        if stDeviceList.nTLayerType == MCC.MV_GIGE_DEVICE:
            nPacketSize = cam.MV_CC_GetOptimalPacketSize()
            if int(nPacketSize) > 0:
                ret = cam.MV_CC_SetIntValue("GevSCPSPacketSize", nPacketSize)
                if ret != 0:
                    self.Tool.printWarning(
                        "[Camera] 相機獲取最佳網絡包失敗! ret[0x%x]" % ret)
            else:
                self.Tool.printWarning(
                    "[Camera] 相機獲取最佳網絡包失敗! ret[0x%x]" % nPacketSize)

        # ch:设置触发模式为on | en:Set trigger mode as on
        ret = cam.MV_CC_SetEnumValue("TriggerMode", MCC.MV_TRIGGER_MODE_OFF)
        # ret = cam.MV_CC_SetEnumValue("TriggerMode", MCC.MV_TRIGGER_MODE_ON)
        if ret != 0:
            self.Tool.printError("Set trigger mode fail! ret[0x%x]" % ret)
            sys.exit()

        # ch:注册抓图回调 | en:Register image callback
        
        CALL_BACK_FUN = self.__FrameInfoCallBack()(self.__callback)
        ret = cam.MV_CC_RegisterImageCallBackEx(CALL_BACK_FUN, None)
        if ret != 0:
            self.Tool.printError(
                "[Camera] 相機註冊回調失敗! ret[0x%x]" % ret)
            sys.exit()

        ret = cam.MV_CC_StartGrabbing()
        if ret != 0:
            self.Tool.printError("[Camera] 相機開始取流失敗! ret[0x%x]" % ret)
            sys.exit()

        self.Tool.print("[Camera %d] 相機運行中.." %nConnectionNum)
        self.cam = cam
        while True:
            if self.stop_camera:
                self.__close_camera()
            time.sleep(1)

    def __close_camera(self):
        self.Tool.print("Close camera..")
        cam = self.cam
        # ch:停止取流 | en:Stop grab image
        ret = cam.MV_CC_StopGrabbing()
        if ret != 0:
            self.Tool.printError("[Camera] 相機停止取流失敗! ret[0x%x]" % ret)
            sys.exit()

        # ch:关闭设备 | Close device
        ret = cam.MV_CC_CloseDevice()
        if ret != 0:
            self.Tool.printError("[Camera] 相機關閉失敗! ret[0x%x]" % ret)
            sys.exit()

        # ch:销毁句柄 | Destroy handle
        ret = cam.MV_CC_DestroyHandle()
        if ret != 0:
            self.Tool.printError("[Camera] 銷毀句柄失敗! ret[0x%x]" % ret)
            sys.exit()

        self.Tool.print("[Camera] 關閉相機作業結束.",True)

    def close_camera(self):
        self.stop_camera = True

    def get_image(self):
        if self.stop_camera == True:
            self.Tool.printError("[Camera] 相機未啟動, 請重新啟動相機.")
            return None
        self.need_one_frame = True
        while True:
            if not self.image is None:
                result_img = self.image
                self.need_one_frame = False
                self.image = None
                return result_img
            time.sleep(0.05)
    

if __name__ == "__main__":
    tool = Tool()
    config = {"IP": "10.64.57.6"}
    camera = HikvisionCamera(tool=tool, config=config)
    time.sleep(5)
    try:
        while True:
            image = camera.get_image()
            if image is not None:
                cv2.imwrite(f'image/{datetime.now().strftime("%H:%M:%S")}.jpg', image)
                time.sleep(2)
    finally:
        camera.close_camera()
    pass