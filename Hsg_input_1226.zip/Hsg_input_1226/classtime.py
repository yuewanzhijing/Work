import re
from collections import defaultdict

# 定义日志文件路径
log_file_path = 'KS_RunningLog2024-08-16.log'

# 创建一个字典以按时间分类日志
logs_by_time = defaultdict(list)
# 创建一个字典以按SN分类日志
logs_by_sn = defaultdict(list)

# 打开并读取日志文件
with open(log_file_path, 'r', encoding='utf-8') as file:
    for line in file:
        # 使用正则表达式提取时间戳和日志内容
        match = re.match(r'\[(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})\]\[(\w+)\] (.*)', line)
        if match:
            date = match.group(1)  
            time = match.group(2)   
            level = match.group(3)      
            message = match.group(4)     
            # 将日志条目添加到相应的时间键下
            logs_by_time[time].append({
                'message': message
            })
        matchSN = re.match(r'named\s+([^\s]+)',line)
        if matchSN:
            print(matchSN.group(1))

# 输出按时间分类的日志
# for time, entries in logs_by_time.items():
#     print(f"时间: {time}")
#     for entry in entries:
#         print(f"消息: {entry['message']}")