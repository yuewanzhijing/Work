import shutil
from flask import Flask, send_file
from flask_cors import CORS
import os
import zipfile
import tempfile
from gevent import pywsgi

app = Flask(__name__)
CORS(app)
@app.route('/', methods=["GET","POST"])
def download():
     # 创建压缩文件
            
            if os.path.exists("dist.zip"):
                cache = tempfile.NamedTemporaryFile()
                with open("dist.zip",'rb') as fp:
                        shutil.copyfileobj(fp,cache)
                        cache.flush()
                cache.seek(0)
            else:
                if os.path.isdir("dist"):
                    with zipfile.ZipFile("dist.zip", 'w') as ziptool:
                        for filename in os.listdir("dist/Hsg_input"):
                            ziptool.write(os.path.join("dist/Hsg_input",filename))
                    cache = tempfile.NamedTemporaryFile()
                    with open("dist.zip",'rb') as fp:
                            shutil.copyfileobj(fp,cache)
                            cache.flush()
                    cache.seek(0)
                else:
                       return "File not found"
            return send_file(cache, as_attachment=True, download_name="HSG_INPUT.zip")


if __name__ == "__main__":
    server = pywsgi.WSGIServer(('0.0.0.0',5003),app)
    print("请勿随便关闭此中端!!!")
    print("此终端提供HSG-INPUT程序下载功能")
    print("感谢!!!")
    server.serve_forever()
    