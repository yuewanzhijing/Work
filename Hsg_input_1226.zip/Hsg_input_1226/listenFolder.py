from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import time
import shutil
import os


# 定义事件处理器类
class MyHandler(FileSystemEventHandler):
    def __init__(self) -> None:
        super().__init__()


    def on_created(self, event):
        print(event.src_path)

    def on_deleted(self, event):
        print(f"已删除{event.src_path}")




 
if __name__ == '__main__':
    input1 = "E:\\watchdog\\img"
    # input2 =   "E:\\watchdog\\img1"
    event_handler = MyHandler()
    observer = Observer()
    observer.schedule(event_handler, input1, recursive=True)
    # observer.schedule(event_handler, input2, recursive=True)
    observer.start()
    print(f'Starting to watch Img for file system events...')
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()