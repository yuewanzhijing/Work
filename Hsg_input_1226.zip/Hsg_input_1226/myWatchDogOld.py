from datetime import datetime, timedelta
import shutil
from watchdog.events import FileSystemEventHandler
import time
import os
from prediction import BackUpServer, LocalPrediction, CambrianPrediction
from configuration import Configuration
from globals import UP_IMAGE_INFO_TABLE, DOWN_IMAGE_INFO_TABLE

def wait_for_file_stability(file_path):
        previous_size = -1
        while True:
            current_size = os.path.getsize(file_path)
            if current_size == previous_size:
                break
            previous_size = current_size
            time.sleep(0.1)




# 定义事件处理器类
class MyHandler(FileSystemEventHandler):
    cambrian_prediction = CambrianPrediction()
    upload_backup_fail = set()
    upload_backup_success = set()
    upload_fail_info = {
        "hour_later":None,
        "fail_num":0,
        "next_retry_time":None
    }

    def __init__(self, Logger, table_record) -> None:
        super().__init__()
        self.log = Logger
        self.table_record = table_record
        self.up_record_number = 1
        self.down_record_number = 1
        self._init_predictor()
        self._ensure_dirs()
        self._process_failed_uploads()
        self._upload_pre_images()

    def _init_predictor(self):
        try:
            self.predictior = LocalPrediction(self.log)
            self.localserver_available = True
        except Exception as e:
            self.log.printError(e)
            self.backupserver = BackUpServer(self.log)
            self.localserver_available = False

    def _ensure_dirs(self):
        for path, message in [(Configuration.UpLoadFailDir, "上传失败文件夹"), (Configuration.DataSetDir, "图片临时存储文件夹")]:
            if not os.path.exists(path):
                os.makedirs(path)
                self.log.print(f"已创建{message}:{path}", True)

    def _process_failed_uploads(self):
        self._process_files(Configuration.UpLoadFailDir)

    def _upload_pre_images(self):
        self._process_files(Configuration.DataSetDir, length_check=Configuration.bSNLengthCheck, length_tuple=Configuration.iSNLength)

    def _process_files(self, dir_path, length_check=0, length_tuple=()):
        file_list = [f for f in os.listdir(dir_path) if f.lower().endswith(('.jpg', '.jpeg'))]
        for filename in file_list:
            sn, ext = self._get_filename_info(filename)
            source_file = os.path.join(dir_path, filename)
            if length_check and not len(sn) in length_tuple:
                self.log.printWarning(f"{filename} SN长度为{len(sn)}, 与{length_tuple}不符, 不会上传预测!!!")
                continue
            result = self._on_predict(source_file)
            self.on_record(sn, self._camera_direction(ext), result)

    def on_created(self, event):
        file_path = event.src_path
        sn, ext = self._get_filename_info(file_path)
        wait_for_file_stability(file_path)
        result = self._on_predict(file_path)
        self.on_record(sn, camera_direction, result)

    def _get_filename_info(self, file_path):
        sn = os.path.splitext(os.path.basename(file_path))[0]
        ext = os.path.splitext(file_path)[1].lower()
        return sn, ext

    def _camera_direction(self, extension):
        return "UpCameraRecord" if extension in ('.jpg',) else "DownCameraRecord"
    
    def _move_image(self,src,dst):
        if not os.path.abspath(src) == os.path.abspath(dst):
            if os.path.exists(dst):
                os.remove(dst)
            shutil.move(src,dst)

    def _on_predict(self, file_path):
        result = [{},None,None]
        if self.localserver_available:
            try:
                result = self._attempt_local_upload(file_path)
            except Exception :
                MyHandler.upload_fail_info['fail_num'] = MyHandler.upload_fail_info['fail_num'] + 1
                if MyHandler.upload_fail_info['hour_later'] is None:
                    MyHandler.upload_fail_info['hour_later'] = datetime.now()+timedelta(hours=1)
                else:
                    if MyHandler.upload_fail_info['hour_later'] >= datetime.now():
                        if  MyHandler.upload_fail_info['fail_num'] >=5 :
                            self.localserver_available = False
                            if MyHandler.upload_fail_info['next_retry_time'] is None:
                                MyHandler.upload_fail_info['next_retry_time'] = datetime.now()+timedelta(minutes=Configuration.IntervalConnectToLocal)
                            MyHandler.upload_fail_info['hour_later'] = None
                            MyHandler.upload_fail_info['fail_num'] = 0
                    else:
                        MyHandler.upload_fail_info['hour_later'] = None
                        MyHandler.upload_fail_info['fail_num'] = 0
                result = self._attempt_backup_upload(file_path)
        else:
                if  MyHandler.upload_fail_info['next_retry_time'] and MyHandler.upload_fail_info['next_retry_time'] <= datetime.now():
                    MyHandler.upload_fail_info['next_retry_time'] = None
                    try:
                        if self.predictior is None:
                            self.predictior = LocalPrediction(self.log)
                        result = self._attempt_local_upload(file_path)
                        self.localserver_available = True
                    except Exception as e:
                        self.log.printError(f"{Configuration.LocalServerIp} 预测失败!!! {e}")
                        if os.path.exists(file_path):
                                dst_dir = Configuration.UpLoadFailDir
                                basename = os.path.basename(file_path)
                                dst_path = os.path.join(dst_dir,basename)
                                self._move_image(file_path,dst_path)
                                result = self._attempt_backup_upload(dst_path)
                result = self._attempt_backup_upload(file_path)
        return result

    def _attempt_local_upload(self, file_path):
        result = [{},None,None]
        if os.path.exists(file_path):
            try:
                result[1] = datetime.now()
                if "Local" == Configuration.predictUrl:
                    self.log.print(f"开始上传{file_path}",True)
                    result[0] = self.predictior.predict(file_path)
                elif "Cambrian" == Configuration.predictUrl:
                    self.log.print(f"开始上传{file_path}",True)
                    result[0] = MyHandler.cambrian_prediction.predict(file_path)
                result[2] = datetime.now()
                self.log.print(f"已获取到{file_path}的预测结果: {result[0]}",True)
                os.remove(file_path)
            except Exception as e:
                self.log.printError(f"{Configuration.LocalServerIp} 预测 {file_path}失败: {e},即将上传到 {Configuration.BackUpServerIpUploadUrl}",True)
                raise
        return result

    def _attempt_backup_upload(self, fail_file_path):
        result = [{},None,None]
        if os.path.exists(fail_file_path):
            dst_dir = Configuration.UpLoadFailDir
            basename = os.path.basename(fail_file_path)
            dst_path = os.path.join(dst_dir,basename)
            try:
                if self.backupserver is None:
                        self.backupserver = BackUpServer(self.log)
            except Exception as e:
                self.log.printError(f"连接到{Configuration.BackUpServerIp}:{Configuration.BackUpServerIpPort}失败!!!")
                MyHandler.upload_backup_fail.add(dst_path)
            else:
                    self._move_image(fail_file_path,dst_path)
                    try:
                        sn = self._get_filename_info(fail_file_path)[0]
                        result[1] = datetime.now()
                        result[0] = self.backupserver.upload(sn)
                        result[2] = datetime.now()
                        self.log.print(f"已从{Configuration.BackUpServerIpUploadUrl}获取到{dst_path}的预测结果: {result[0]}",True)
                        MyHandler.upload_backup_success.add(dst_path)
                    except Exception as e:
                        self.log.printError(f"{dst_path}上传失败: {e}",True)
                        MyHandler.upload_backup_fail.add(dst_path) 
        return result



    def on_record(self, sn, camera_direction, result):
        record_data = {
            'no': self.up_record_number if camera_direction == "UpCameraRecord" else self.down_record_number,
            'upload_time': result[1].strftime('%Y-%m-%d %H:%M:%S') if result[1] else "None",
            'sn': sn,
            'predict_result': result[0].get('result', "None"),
            'sf_result': result[0].get('sfis_result', "None"),
            'sf_info': result[0].get('sfis_str', "None"),
            'get_result_time': result[2].strftime('%Y-%m-%d %H:%M:%S') if result[2] else "None",
            'interval': str(result[2] - result[1]) if result[1] and result[2] else "None"
        }
        if camera_direction == "UpCameraRecord":
            UP_IMAGE_INFO_TABLE.appendleft(record_data)
            self.up_record_number += 1
        else:
            DOWN_IMAGE_INFO_TABLE.appendleft(record_data)
            self.down_record_number += 1
        self.table_record.write_record(camera_direction, [record_data])
    
    def reupload(self):
       while True:
            time.sleep(Configuration.repredictInterval)
            fail_file_path = None
            show_result = False
            if len(MyHandler.upload_backup_success) > 0 :
                if self.localserver_available:
                    fail_file_path =MyHandler.upload_backup_success.pop()
                    try:
                        result = self._attempt_local_upload(fail_file_path)
                    except Exception :
                        result = self._attempt_backup_upload(fail_file_path)
                    show_result = False
            elif len(MyHandler.upload_backup_fail) > 0:
                fail_file_path =MyHandler.upload_backup_fail.pop()
                if self.localserver_available:
                    try:
                        result = self._attempt_local_upload(fail_file_path)
                    except Exception:
                        result = self._attempt_backup_upload(fail_file_path)
                else:
                    result = self._attempt_backup_upload(fail_file_path)
                show_result = True

            if show_result and not fail_file_path is None:
                    name_info = self._get_filename_info(fail_file_path)
                    sn = name_info[0]
                    camera_up_or_dwon= self._camera_direction(name_info[1])
                    self.on_record(sn,camera_up_or_dwon,result)

    def on_deleted(self, event):
        self.log.printWarning(f"{event.src_path} 已删除!!!" if self.localserver_available else f"{event.src_path} 已移动到 {Configuration.UpLoadFailDir}!!!")

class BackUpHandler(FileSystemEventHandler):
    def __init__(self,Logger) -> None:
        super().__init__()
        self.log = Logger
        
    def on_created(self, event):
        
        file_path = event.src_path
        wait_for_file_stability(file_path)
        
        self.log.printWarning(f"已暂存predict为None或上传失败的图片{file_path}",True)

    def on_deleted(self, event):
        self.log.printWarning(f"{event.src_path} 已删除!!!")