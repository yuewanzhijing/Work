import dash
from dash import dcc, html, Input, Output, dash_table
import plotly.graph_objs as go
from datetime import datetime
from waitress import serve
from globals import *
from Cosmetic import Cosmetic



class DashboardApp:
    def __init__(self,history_record):
        self.app = dash.Dash(__name__)
        self.show_previous_record(history_record)
        

        # 设置应用布局
        self.app.layout = self.create_layout()

        # 设置回调
        self.set_callbacks()

    def show_previous_record(self,history_record):
        now_time = datetime.now()
        result = history_record.read_uph(now_time)

        for one_record in result:
            for time,uph in one_record.items():
                UPH_TIME.append(datetime.strptime(time,"%Y-%m-%d_%H:%M:%S"))
                UPH_PER_HOUR.append(uph)

        result = history_record.read_scan_rate(now_time)

        for one_record in result:
            for time,scan_rate in one_record.items():
                SCAN_TIME.append(datetime.strptime(time,"%Y-%m-%d_%H:%M:%S"))
                SCAN_RATE_PER_HOUR.append(scan_rate)
        
    def create_layout(self):
        return html.Div(
            [
                html.Div(style={'display': 'flex'}, children=[
                html.Div(id='number-uph', style={'fontSize': 24,'flex': '0.9','textAlign': 'center','marginTop': '0.5%'}),
                html.Div(id='number-scan-rate', style={'fontSize': 24,'flex': '1','textAlign': 'center','marginTop': '0.5%'}),
            ]),
                # html.Div(id='number-uph', style={'fontSize': 24, 'position': 'absolute', 'top': '2%', 'left': '22%'}),
                # html.Div(id='number-scan-rate', style={'fontSize': 24, 'position': 'absolute', 'top': '2%', 'left': '70%'}),
                html.Div([
                    dcc.Graph(id='uph-update-graph', style={'margin-top': '0%', 'width': '50%','height': '100%'}),
                    dcc.Graph(id='scan-rate-update-graph', style={'margin-top': '0%', 'width': '50%','height': '100%'}),
                ], style={'display': 'flex','height': '30vh'}),
                dcc.Interval(
                    id='interval-component',
                    interval= 10 * 1000 * 60,  # 每10分钟更新一次
                    n_intervals=0
                ),
                dcc.Interval(
                    id='table-interval-component',
                    interval= 2 * 1000,  # 每2秒更新一次
                    n_intervals=0
                ),
                html.Div([
                    html.Div([
                        dash_table.DataTable(
                            id='data-table',
                            columns=[
                                {'name': 'No', 'id': 'no'},
                                {'name': 'upload_time', 'id': 'upload_time'},
                                {'name': 'SN', 'id': 'sn'},
                                {'name': 'predict_result', 'id': 'predict_result'},
                                {'name': 'sf_result', 'id': 'sf_result'},
                            ],
                            data=list(UP_IMAGE_INFO_TABLE),
                            style_header={'backgroundColor': 'gray', 'color': 'white','position': 'sticky','top': 0,'zIndex': 100},
                            style_cell={'textAlign': 'center', 'minWidth': '50px', 'whiteSpace': 'normal'},
                            style_table={'overflowY': 'auto',  # 当内容超出时显示滚动条
                                        'height': '70vh',     # 设置表格的高度
                                        'width': '100%' },
                            style_data_conditional=[
                                {
                 'if': {'column_id': ['no','upload_time','sn','predict_result','sf_result'],'filter_query': '{sf_result} ="FAIL"',},
                'backgroundColor': 'yellow'},
                {
                 'if': {'column_id': ['no','upload_time','sn','predict_result','sf_result'],'filter_query': '{predict_result} ="None" || {sf_result} ="None" || {predict_result} ="FAIL"',},
                'backgroundColor': 'red'}
            ],
                        )
                    ], style={'flex': '1'}),  # 第一个表格占据一半的空间
                    html.Div([
                        dash_table.DataTable(
                            id='data-table2',
                            columns=[
                                {'name': 'No', 'id': 'no'},
                                {'name': 'upload_time', 'id': 'upload_time'},
                                {'name': 'SN', 'id': 'sn'},
                                {'name': 'predict_result', 'id': 'predict_result'},
                                {'name': 'sf_result', 'id': 'sf_result'},
                            ],
                            data=list(DOWN_IMAGE_INFO_TABLE),
                            style_header={'backgroundColor': 'gray', 'color': 'white','position': 'sticky','top': 0,'zIndex': 100},
                            style_cell={'textAlign': 'center', 'minWidth': '50px', 'whiteSpace': 'normal'},
                            style_table={'overflowY': 'auto',  # 当内容超出时显示滚动条
                                          'height': '70vh',     # 设置表格的高度
                                          'width': '100%' },
                             style_data_conditional=[
                {
                 'if': {'column_id': ['no','upload_time','sn','predict_result','sf_result'],'filter_query': '{sf_result} ="FAIL"',},
                'backgroundColor': 'yellow'},
                {
                'if': {'column_id': ['no','upload_time','sn','predict_result','sf_result'],'filter_query': '{predict_result} ="None" || {sf_result} ="None" || {predict_result} ="FAIL"',},
                'backgroundColor': 'red'}
            ]
                        )
                    ], style={'flex': '1'})  # 第二个表格占据一半的空间
                ], style={'display': 'flex','margin-top': '0%'})  # 将两个表格放在同一行
            ]
        )

    # 每0.4秒检查一次

    def set_callbacks(self):
        @self.app.callback(
            Output('uph-update-graph', 'figure'), 
            Input('interval-component', 'n_intervals')
        )
        def update_uph(n):
            # 更新图表
            figure_uph = go.Figure()
            figure_uph.add_trace(go.Scatter(x=list(UPH_TIME), y=list(UPH_PER_HOUR), mode='lines+markers'))
            # 设置图表布局
            figure_uph.update_layout(
                margin=dict(t=30),
                xaxis_title='时间',
                yaxis_title='UPH',
                xaxis=dict(tickmode='linear', dtick=3600*1000, tickformat='%H:%M')  # 设置X轴为小时
            )
            return figure_uph  # 返回图表数据

        @self.app.callback(
            Output('scan-rate-update-graph', 'figure'), 
            Input('interval-component', 'n_intervals')
        )
        def update_scan_rate(n):
            # 更新图表
            figure_scan_rate = go.Figure()
            figure_scan_rate.add_trace(go.Scatter(x=list(SCAN_TIME), y=list(SCAN_RATE_PER_HOUR), mode='lines+markers',
                                                 line=dict(color='green')))
            # 设置图表布局
            figure_scan_rate.update_layout(
                margin=dict(t=30),
                xaxis_title='时间',
                yaxis_title='扫码率',
                xaxis=dict(tickmode='linear', dtick=3600*1000, tickformat='%H:%M')  # 设置X轴为小时
            )
            return figure_scan_rate

        @self.app.callback(
            Output('number-uph', 'children'),
            Input('interval-component', 'n_intervals')
        )
        def update_number_uph(n):
            # 直接使用生成线程中更新的数字
            return f"UPH: {Cosmetic.UPH_LAST_HOUR}"
        
        @self.app.callback(
            Output('number-scan-rate', 'children'),
            Input('interval-component', 'n_intervals')
        )
        def update_number_scan_rate(n):
            # 直接使用生成线程中更新的数字
            return f"扫码率: {Cosmetic.SCAN_RATE_LAST_HOUR}%"

        @self.app.callback(
            Output('data-table', 'data'),  # 添加输出以更新表格数据
            Input('table-interval-component', 'n_intervals')
        )
        def update_UP_IMAGE_INFO_TABLE(n):
            return list(UP_IMAGE_INFO_TABLE)  # 返回表格数据

        @self.app.callback(
            Output('data-table2', 'data'),  # 更新第二个表格的数据
            Input('table-interval-component', 'n_intervals')
        )
        def update_DOWN_IMAGE_INFO_TABLE(n):
            return list(DOWN_IMAGE_INFO_TABLE)  # 返回第二个表格的数据

    def run(self):
        serve(self.app.server, host="127.0.0.1", port=8050, threads=8,_quiet=True)