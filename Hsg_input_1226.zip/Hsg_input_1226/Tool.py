'''
@Author: Melt_Min
@CreateTime: 2021/12/13
@Usage: Public
'''

import datetime
import os
from time import sleep
import psutil
# import pandas

class Tool():
    def __init__(self):
        self.Logger = Logger(self)

    def getTimeYMDHMSMs(self):
        return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

    def getTimeYMDHMS(self):
        return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    def getTimeYMD(self):
        return datetime.datetime.now().strftime('%Y-%m-%d')

    def getTimeHMS(self):
        return datetime.datetime.now().strftime('%H:%M:%S')

    def print(self, txt, writeLog=False):
        print(f"[{self.getTimeYMDHMS()}][Info] {txt}")
        if self.Logger != None and writeLog:
            self.Logger.write_log(f"[Info] {txt}")

    def printWarning(self, txt, writeLog=True):
        # print(f"\033[30;43m{f'[{self.getTimeYMDHMS()}][Warning] {txt}'}\033[0m") # color:black, background-color:yellow
        # color:yellow, background-color:black
        print(
            f"\033[33;40m{f'[{self.getTimeYMDHMS()}][Message] {txt}'}\033[0m")
        if self.Logger != None and writeLog:
            self.Logger.write_log(f"[Message] {txt}")

    def printError(self, txt, writeLog=True):
        # color:white, background-color:red
        print(f"\033[37;41m{f'[{self.getTimeYMDHMS()}][Error] {txt}'}\033[0m")
        # print(f"\033[31;40m{f'[{self.getTimeYMDHMS()}][Error] {txt}'}\033[0m") # color:red, background-color:black
        if self.Logger != None and writeLog:
            self.Logger.write_log(f"[Error] {txt}")

    def doShell(self, command, password="pega#1234", sleeptime=1):
        with open("./shell.sh", "w") as f:
            f.write(
                rf"""#! /bin/bash
sudo -S {command}<<EOF
{password}
EOF""")
        sleep(0.5)
        os.system("./shell.sh")

        if sleeptime < 0.5:
            sleeptime = 0.5
        sleep(sleeptime)
        with open("./shell.sh", "w") as f:
            f.write("")

    def programIsRunning(self, name):
        flag = False
        try:
            for pid in psutil.pids():
                p = psutil.Process(pid)
                if p.name() == name:
                    flag = True
        except:
            self.printWarning(
                "無法檢索程式運行列表, 因為 System-Monitor 未在運行中, 或模塊未開放.")
            flag = None
        return flag

    def killProgram(self, name):
        flag = False
        try:
            for pid in psutil.pids():
                p = psutil.Process(pid)
                if p.name() == name:
                    p.kill()
                    flag = True
        except:
            self.printWarning(
                "無法檢索程式運行列表, 因為 System-Monitor 未在運行中, 或模塊未開放.")
            flag = None
        return flag


class Logger():
    def __init__(self, tool=None):
        if tool != None:
            self.Tool = tool
        else:
            self.Tool = Tool()
        self.logTime = self.Tool.getTimeYMD()
        self.log_dir_path = "./mlog/"
        # self.Tool.print("Log Path:" + self.log_dir_path)

        try:
            if not os.path.exists(self.log_dir_path) or not os.path.isdir(self.log_dir_path):
                os.mkdir(self.log_dir_path)
        except:
            self.Tool.printError(
                f"[Log] 請確保MLog文件夾: {self.log_dir_path} 存在")
            raise NotADirectoryError(
                f"[Log] 請確保MLog文件夾: {self.log_dir_path} 存在")

    def write_log(self, text="", prt=False):
        self.__check_date()
        path = f"{os.path.join(self.log_dir_path,'RunningLog'+self.Tool.getTimeYMD())}.log"
        space = ""
        if len(text) > 0 and text[0] != "[":
            text = " "
        if os.path.exists(path):
            with open(path, "a",encoding='utf-8') as f:
                f.write(f"[{self.Tool.getTimeYMDHMS()}]{space}{text}\n")
        else:
            with open(path, "w",encoding="utf-8") as f:
                f.write(f"[{self.Tool.getTimeYMDHMS()}]{space}{text}\n")
        prt and self.Tool.print(f"[LOG SAVE] 日誌已保存至 {path}")

    def __check_date(self):
        if self.logTime != self.Tool.getTimeYMD():
            self.Tool.print(
                f"更新日誌日期. {self.logTime} => {self.Tool.getTimeYMD()}")
            self.logTime = self.Tool.getTimeYMD()


# class MLogger():
#     def __init__(self):
#         self.Tool = Tool()
#         # try:
#         #     self.pd = __import__("pandas")
#         # except ModuleNotFoundError as e:
#         #     print(e)
#         self.logTime = self.Tool.getTimeYMD()
#         self.log_dir_path = "./mlog/"
#         # self.Tool.print("MLog Path:" + self.log_dir_path)
#         try:
#             if not os.path.exists(self.log_dir_path) or not os.path.isdir(self.log_dir_path):
#                 os.mkdir(self.log_dir_path)
#         except:
#             self.Tool.printError(
#                 f"[Log] 請確保MLog文件夾: {self.log_dir_path} 存在")
#             raise NotADirectoryError(
#                 f"[Log] 請確保MLog文件夾: {self.log_dir_path} 存在")

#         self.__init_dataFrame()

#     def __init_dataFrame(self):
#         self.log = pandas.DataFrame(
#             columns=["isn", "isntime"])

#     def write_log(self,isn="",isntime=""):
#         self.__check_date()
#         self.log.loc[0] = [isn, isntime]
#         self.__save_log(False)

#     def __save_log(self, prt=True):
#         path = f"{os.path.join(self.log_dir_path,'SNLog' + self.Tool.getTimeYMD())}.csv"
#         if os.path.exists(path):
#             self.log.to_csv(path, mode="a", header=False, index=False)
#         else:
#             self.log.to_csv(path, index=False)
#         prt and self.Tool.print(f"[MLOG SAVE] 日誌已保存至 {path}")

#     def __check_date(self):
#         if self.logTime != self.Tool.getTimeYMD():
#             self.__save_log()
#             self.Tool.print(
#                 f"更新日誌日期. {self.logTime} => {self.Tool.getTimeYMD()}")
#             self.logTime = self.Tool.getTimeYMD()
#             self.__init_dataFrame()
