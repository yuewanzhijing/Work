from RS232Controller import *
import serial
import serial.tools.list_ports
import modbus_tk.defines as cst
from modbus_tk import modbus_rtu
from BarcodeScanner import *
from HikvisionClass import *
import cv2
import time
import json
import os
from Tool import Tool
from Tool import MLogger
import datetime
class Cosmetic:
    
    M0=2048
    M1=2049
    M2=2050
    M10=2058
    M11=2059
    M12=2060
    M20=2068
    M21=2069
    M22=2070
    M197=2245
    M198=2246
    M199=2247
    M102=2150
    Barcode=[]
    codeName1=None
    codeName2=[]
    Img1=None
    Img2=None
    State=False
    upLightReady=False
    color1=None
    color2=None
    upopen=False
    downLightReady=False
    colorSame=None
    Compare=[]
    changed=False
    ScanAlready=False
    L1done=False
    tool=Tool()
    try:
        Js=json.load(open('settings.json','r'))
    except Exception as e:
        tool.printError(
                'Reading settings failed失敗')
        tool.printError('原因:{}'.format(e))
    if "True" !=Js['autoLight']:
        first=False
    
    def __init__(self,
                 Plc,
                 Scanner,
                 Cam1,
                 Cam2):
        self.plc=Plc
        self.scanner=Scanner
        self.cam1=Cam1
        self.cam2=Cam2
        # self.uplight=Uplight
        # self.downlight=Downlight
        
        # self.uplight.send_data(lc.create_control_command(1,1,100))
        # self.uplight.send_data(lc.create_control_command(1,2,100))
        # self.uplight.send_data(lc.create_control_command(1,3,100))
        # self.uplight.send_data(lc.create_control_command(1,4,100))
        
        # self.downlight.send_data(lc.create_control_command(1,1,100))
        # self.downlight.send_data(lc.create_control_command(1,2,100))
        # self.downlight.send_data(lc.create_control_command(1,3,100))
        # self.downlight.send_data(lc.create_control_command(1,4,100))
        
    def workPos2(self):
        master=self.plc
        Bsc=self.scanner
        master.set_timeout(1)
        times=1
        mlogger=MLogger()
        # data=master.execute(1,cst.READ_COILS,self.M0,quantity_of_x=1)
        # Cosmetic.tool.printWarning('Receving permissoin sign to scan')
        # print(f'work2 data {data}')
        while True:
            data=master.execute(1,cst.READ_COILS,self.M0,quantity_of_x=1)
            # Cosmetic.tool.printWarning(f'prepare to receive sign to scan {times}')
            while (data[0]!=1):
                data=master.execute(1,cst.READ_COILS,self.M0,quantity_of_x=1)
            Cosmetic.tool.printWarning(f'Receved permissoin sign to scan {times}')
            code=Bsc.getBarcode()
            # print(Barcode)
            if ("NR"!=code):
                Cosmetic.Barcode.append(code)
                if "True" == Cosmetic.Js['autoLight']:
                    if (len(Cosmetic.Compare)<2):
                        Cosmetic.Compare.append(code)
                    if (len(Cosmetic.Compare)==2):
                        if Cosmetic.Compare[0][Cosmetic.Js['ColorIndex']-1:Cosmetic.Js['ColorIndex']-1+Cosmetic.Js['Length_Color']] == Cosmetic.Compare[1][Cosmetic.Js['ColorIndex']-1:Cosmetic.Js['ColorIndex']-1+Cosmetic.Js['Length_Color']]:
                            Cosmetic.colorSame=True
                        else:
                            Cosmetic.colorSame=False
                        if Cosmetic.colorSame == False:
                            Cosmetic.upLightReady=False
                            Cosmetic.downLightReady=False
                        Cosmetic.Compare.remove(Cosmetic.Compare[0])
                master.execute(1,cst.WRITE_SINGLE_COIL,self.M1,quantity_of_x=1,output_value=1)
                # time.sleep(0.5)
                master.execute(1,cst.WRITE_SINGLE_COIL,self.M1,quantity_of_x=1,output_value=0)
                Cosmetic.tool.printWarning(f'sended sign to PLC that scaned {times} has done')
                mlogger.write_log(isn=code,isntime=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                # print(f'M0 = {master.execute(1,cst.READ_COILS,self.M0,quantity_of_x=1)}')
            else:
                # Cosmetic.Barcodelist.remove("NR")
                master.execute(1,cst.WRITE_SINGLE_COIL,self.M2,quantity_of_x=1,output_value=1)
                time.sleep(0.5)
                master.execute(1,cst.WRITE_SINGLE_COIL,self.M2,quantity_of_x=1,output_value=0)
                Cosmetic.tool.printWarning(f'sended sign to PLC that scaned {times} has failed')
                mlogger.write_log(isn="NR",isntime=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            Cosmetic.ScanAlready=True
            times=times+1
            # data=master.execute(1,cst.READ_COILS,self.M0,quantity_of_x=1)
    
    def workPos3(self):
        master=self.plc
        CameraUp=self.cam1
        Flag=("True"==Cosmetic.Js['autoLight'])
        quality=Cosmetic.Js['QUALITY1']
        # namelength=Cosmetic.Js['length']
        times=1
        while True:
            if Cosmetic.ScanAlready==True or Cosmetic.first == True:
                Cosmetic.ScanAlready=False
                data=master.execute(1,cst.READ_COILS,self.M10,quantity_of_x=1)
                # Cosmetic.tool.printWarning(f'prepare to receive sign {times} to take a photo up')
                while (data[0]!=1):
                    data=master.execute(1,cst.READ_COILS,self.M10,quantity_of_x=1)
                Cosmetic.tool.printWarning(f'Receved permissoin sign {times} to take a photo up')
                if (len(Cosmetic.Barcode)!=0):
                    Cosmetic.codeName1=Cosmetic.Barcode[0]
                    Cosmetic.codeName2.append(Cosmetic.codeName1)
                    Cosmetic.L1done=True
                    Cosmetic.Barcode.remove(Cosmetic.Barcode[0])
                    if Flag:
                        Cosmetic.color1=Cosmetic.codeName1[Cosmetic.Js['ColorIndex']-1:Cosmetic.Js['ColorIndex']-1+Cosmetic.Js['Length_Color']]
                        while True:
                            if Cosmetic.upLightReady:
                                Cosmetic.Img1=CameraUp.get_image()
                                break
                    else:
                        Cosmetic.Img1=CameraUp.get_image()
                    # print(f'M0 = {master.execute(1,cst.READ_COILS,self.M0,quantity_of_x=1)}')
                    if (not Cosmetic.Img1 is None):
                        # Name=datetime.datetime.now().strftime('%Y%m%d%H%M%S')
                        cv2.imwrite(f"Image/{Cosmetic.codeName1}.jpg",Cosmetic.Img1,[int(cv2.IMWRITE_JPEG_QUALITY),quality])
                        # cv2.imwrite(f"Image2/{Cosmetic.codeName1}.jpg",Cosmetic.Img1)
                        Cosmetic.tool.print(f'Up-camera takes photo {times} successfully,named {Cosmetic.codeName1}',writeLog=True)
                        master.execute(1,cst.WRITE_SINGLE_COIL,self.M11,quantity_of_x=1,output_value=1)
                        time.sleep(0.5)
                        master.execute(1,cst.WRITE_SINGLE_COIL,self.M11,quantity_of_x=1,output_value=0)
                        Cosmetic.tool.printWarning(f'sended sign {times} to PLC that Up-camera takes a photo has done')
                        # Cosmetic.codeName2=Cosmetic.codeName1
                        # Cosmetic.codeName1="OK"
                        
                    else:
                        Cosmetic.tool.print(f'Up-camera takes photo {times} failed,named {Cosmetic.codeName1}',writeLog=True)
                        master.execute(1,cst.WRITE_SINGLE_COIL,self.M12,quantity_of_x=1,output_value=1)
                        time.sleep(0.5)
                        master.execute(1,cst.WRITE_SINGLE_COIL,self.M12,quantity_of_x=1,output_value=0)
                        Cosmetic.tool.printWarning(f'sended sign {times} to PLC that Up-camera takes a photo has failed')
                        print('get UpImage failed')
                # data=master.execute(1,cst.READ_COILS,self.M10,quantity_of_x=1)
                # Cosmetic.tool.printWarning('Receving permissoin sign to take a photo up')
                    times=times+1
                Cosmetic.State=True
       
    def workPos4(self):
        master=self.plc
        CameraDown=self.cam2
        Flag=("True"==Cosmetic.Js['autoLight'])
        quality=Cosmetic.Js['QUALITY2']
        times=1
        # namelength=Cosmetic.Js['length']
        # data=master.execute(1,cst.READ_COILS,self.M20,quantity_of_x=1)
        # Cosmetic.tool.printWarning('Receving permissoin sign to take a photo down')
        # print(f'work2 data {data}')
        while True:
                data=master.execute(1,cst.READ_COILS,self.M20,quantity_of_x=1)
                # Cosmetic.tool.printWarning(f'prepare to receive sign {times} to take a photo down')
                while (data[0]!=1):
                    data=master.execute(1,cst.READ_COILS,self.M20,quantity_of_x=1)
                Cosmetic.tool.printWarning(f'Receved permissoin sign {times} to take a photo down')
                # time.sleep(1)
                delay=Cosmetic.Js['delayTime']
                time.sleep(delay)
                # if (Cosmetic.State):
                #     Cosmetic.State=False
                if Flag:
                    Cosmetic.color2=Cosmetic.codeName2[0][Cosmetic.Js['ColorIndex']-1:Cosmetic.Js['ColorIndex']-1+Cosmetic.Js['Length_Color']]
                    while True:
                        if Cosmetic.downLightReady:
                            Cosmetic.Img2=CameraDown.get_image()
                            break
                else :
                    Cosmetic.Img2=CameraDown.get_image()
                if (Cosmetic.L1done and not Cosmetic.Img2 is None):
                    Cosmetic.L1done = False
                    cv2.imwrite(f"Image/{Cosmetic.codeName2[0]}.jpeg",Cosmetic.Img2,[int(cv2.IMWRITE_JPEG_QUALITY),quality])
                    # cv2.imwrite(f"Image2/{Cosmetic.codeName2[0]}.jpeg",Cosmetic.Img2)
                    Cosmetic.tool.print(f'Down-camera takes photo {times} successfully,named {Cosmetic.codeName2[0]}',writeLog=True)
                    Cosmetic.codeName2.remove(Cosmetic.codeName2[0])
                    # print(f'po4 codeName2 {Cosmetic.codeName2}')
                    # Cosmetic.codeName2=None
                    master.execute(1,cst.WRITE_SINGLE_COIL,self.M21,quantity_of_x=1,output_value=1)
                    time.sleep(0.5)
                    master.execute(1,cst.WRITE_SINGLE_COIL,self.M21,quantity_of_x=1,output_value=0)
                    Cosmetic.tool.printWarning(f'sended sign {times} to PLC that Down-camera takes a photo has done')
                else:
                    Cosmetic.tool.printError(f'Down-camera takes photo {times} failed,named {Cosmetic.codeName2[0]}',writeLog=True)
                    master.execute(1,cst.WRITE_SINGLE_COIL,self.M22,quantity_of_x=1,output_value=1)
                    time.sleep(0.5)
                    master.execute(1,cst.WRITE_SINGLE_COIL,self.M22,quantity_of_x=1,output_value=0)
                    Cosmetic.tool.printWarning(f'sended sign {times} to PLC that Down-camera takes a photo has failed')
                    print('get DownImage failed')
                times=times+1
    
    def upLight(self,port,baud,js):
        light1=COM(port,baud)
        while True:
            if (Cosmetic.first and Cosmetic.colorSame) or Cosmetic.colorSame == False:
                light1.send_data(lc.create_control_command(3,1,js[Cosmetic.color1]))
                Cosmetic.tool.print(f'upLight 1 has changed to {js[Cosmetic.color1]}',writeLog=True)
                time.sleep(0.25)
                light1.send_data(lc.create_control_command(3,2,js[Cosmetic.color1]))
                Cosmetic.tool.print(f'upLight 2 has changed to {js[Cosmetic.color1]}',writeLog=True)
                time.sleep(0.25)
                light1.send_data(lc.create_control_command(3,3,js[Cosmetic.color1]))
                Cosmetic.tool.print(f'upLight 3 has changed to {js[Cosmetic.color1]}',writeLog=True)
                time.sleep(0.25)
                light1.send_data(lc.create_control_command(3,4,js[Cosmetic.color1]))
                Cosmetic.tool.print(f'upLight 4 has changed to {js[Cosmetic.color1]}',writeLog=True)
                time.sleep(0.25)
            Cosmetic.upLightReady=True
                

    def downLight(self,port,baud,js):
        light2=COM(port,baud)
        while True:
            if (Cosmetic.first and Cosmetic.colorSame) or Cosmetic.colorSame == False:
                Cosmetic.first = False
                light2.send_data(lc.create_control_command(3,1,js[Cosmetic.color2]))
                Cosmetic.tool.print(f'downLight 1 has changed to {js[Cosmetic.color2]}',writeLog=True)
                time.sleep(0.25)
                light2.send_data(lc.create_control_command(3,2,js[Cosmetic.color2]))
                Cosmetic.tool.print(f'downLight 2 has changed to {js[Cosmetic.color2]}',writeLog=True)
                time.sleep(0.25)
                light2.send_data(lc.create_control_command(3,3,js[Cosmetic.color2]))
                Cosmetic.tool.print(f'downLight 3 has changed to {js[Cosmetic.color2]}',writeLog=True)
                time.sleep(0.25)
                light2.send_data(lc.create_control_command(3,4,js[Cosmetic.color2]))
                Cosmetic.tool.print(f'downLight 4 has changed to {js[Cosmetic.color2]}',writeLog=True)
                time.sleep(0.25)
            Cosmetic.downLightReady=True
    # def recover(self):
    #     master=self.plc
    #     master.execute(1,cst.WRITE_SINGLE_REGISTER,self.X05,quantity_of_x=1,output_value=1)
    #     master.set_timeout(1)
    #     master.execute(1,cst.WRITE_DISCRETE_INPUTS,self.X05,quantity_of_x=1,output_value=0)
    def recover(self):
        master=self.plc
        master.set_timeout(1)
        try :
            master.execute(1,cst.WRITE_SINGLE_COIL,self.M197,quantity_of_x=1,output_value=1)
            Cosmetic.tool.print('Stop button is pressed',writeLog=True)
        except Exception as e:
            Cosmetic.tool.printWarning('原因:{}'.format(e))
        time.sleep(0.5)
        try :
            master.execute(1,cst.WRITE_SINGLE_COIL,self.M197,quantity_of_x=1,output_value=0)
            Cosmetic.tool.print('Stop button is released',writeLog=True)
        except Exception as e:
            Cosmetic.tool.printWarning('原因:{}'.format(e))
        time.sleep(0.25)
        try:
            master.execute(1,cst.WRITE_SINGLE_COIL,self.M199,quantity_of_x=1,output_value=1)
            Cosmetic.tool.print('Recover button is pressed',writeLog=True)
        except Exception as e:
            Cosmetic.tool.printWarning('原因:{}'.format(e))
        # time.sleep(0.25)
        try:
            master.execute(1,cst.WRITE_SINGLE_COIL,self.M199,quantity_of_x=1,output_value=0)
            Cosmetic.tool.print('Recover button is released',writeLog=True)
        except Exception as e:
            Cosmetic.tool.printWarning('原因:{}'.format(e))
        # time.sleep(0.25)
        try:
            Flag=master.execute(1,cst.READ_COILS,self.M102,quantity_of_x=1)
            Cosmetic.tool.print('Plate rotates',writeLog=True)
        except Exception as e:
            Cosmetic.tool.printWarning('原因:{}'.format(e))
        while Flag[0]!=1:
            Flag=master.execute(1,cst.READ_COILS,self.M102,quantity_of_x=1)
            Cosmetic.tool.print('Plate is rotating',writeLog=True)
        Cosmetic.tool.print('Plate stoped',writeLog=True)
        try:
            master.execute(1,cst.WRITE_SINGLE_COIL,self.M198,quantity_of_x=1,output_value=1)
            Cosmetic.tool.print('Start-button is pressed',writeLog=True)
        except Exception as e:
            Cosmetic.tool.printWarning('原因:{}'.format(e))
        # time.sleep(0.25)
        try :
            master.execute(1,cst.WRITE_SINGLE_COIL,self.M198,quantity_of_x=1,output_value=0)
            Cosmetic.tool.print('Start-button is released',writeLog=True)
        except Exception as e:
            Cosmetic.tool.printWarning('原因:{}'.format(e))
    
if __name__=='__main__':
    try:
        with open('settings.json','r') as setting:
            js=json.load(setting)
        os.system('./USB.sh')
        with open('USB.txt','r') as data:
            Res=data.readlines()
    except Exception as e:
        Cosmetic.tool.printError('原因:{}'.format(e))
    for i in range(len(Res)):
        Res[i]=Res[i].split('>')[1]
    Map={}
    for i in range(len(Res)):
        tmp=Res[i].split('/')
        port=tmp[7]
        tty=tmp[-1].replace('\n','')
        Map[port]=tty
    plcPort='/dev/'+Map['1-2:1.0']
    uplightPort='/dev/'+Map['1-5.2']
    downlightPort='/dev/'+Map['1-5.3']
    Plc=modbus_rtu.RtuMaster(serial.Serial(plcPort,baudrate=9600,bytesize=8,parity='E',stopbits=1))
    # Plc.set_timeout(1)
    # Plc.execute(1,cst.WRITE_SINGLE_COIL,1029,quantity_of_x=1,output_value=1)
    Scanner=BarcodeScanner(js['BarcodeScannerIp'],js['BarcodeScannerPort'])
    Cam1=HikvisionCamera(config={"IP":js['UpCameraIp']})
    time.sleep(3)
    Cam2=HikvisionCamera(config={"IP":js['DownCameraIp']})
    # Uplight=COM(uplightPort,9600)
    # DownLight=COM(downlightPort,9600)
    try :
        Cos=Cosmetic(Plc,Scanner,Cam1,Cam2)
    except Exception as e:
        Cosmetic.tool.printError(
                'Creating a new Object失敗')
        Cosmetic.tool.printError('原因:{}'.format(e))
    
    thread2 = threading.Thread(target=Cos.workPos2)
    thread3 = threading.Thread(target=Cos.workPos3)
    thread4 = threading.Thread(target=Cos.workPos4)
    if "True"==js['autoLight']:
        thread5 = threading.Thread(target=Cos.upLight,args=(uplightPort,9600,js))
        thread6 = threading.Thread(target=Cos.downLight,args=(downlightPort,9600,js))
        Cosmetic.tool.print('Auto-Type light',writeLog=True)
    else:
        Cosmetic.tool.print('handle light',writeLog=True)
    
    thread2.start()
    thread3.start()
    thread4.start()
    if "True"==js['autoLight']:
        thread5.start()
        thread6.start()
    
