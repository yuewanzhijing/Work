import json
import os
import pandas as pd
from datetime import datetime, timedelta
from configuration import Configuration

class TableRecord():

    def __init__(self):
        if not os.path.isdir(Configuration.RECORD_DIR):
            os.mkdir(Configuration.RECORD_DIR)
    
    def write_record(self,camera_up_or_down,data):
        present_day = datetime.now().strftime('%Y-%m-%d')
        record_path = os.path.join(Configuration.RECORD_DIR,"{}_{}.csv".format(camera_up_or_down,present_day))

        new_df = pd.DataFrame(data)

        if os.path.exists(record_path):
            new_df.to_csv(record_path, mode='a', header=False, index=False,encoding='utf-8-sig')
        else:
            
            new_df.to_csv(record_path, mode='w', index=False,encoding='utf-8-sig')

#包括了UPH和扫码率
class HistoryRecord():

    def write_uph(self,data):
        present_day = datetime.now().strftime('%Y-%m-%d')
        record_path = os.path.join(Configuration.RECORD_DIR,"uph_{}.json".format(present_day))
        if os.path.exists(record_path):
            with open(record_path,'r',encoding='utf-8') as file:
                history_file = json.load(file)

            history_file['uph_record'].append(data)

        else:
            history_file = {"uph_record":[data]}

        with open(record_path, 'w', encoding='utf-8') as file:
                json.dump(history_file, file)

    def write_scan_rate(self,data):
        present_day = datetime.now().strftime('%Y-%m-%d')
        record_path = os.path.join(Configuration.RECORD_DIR,"scan_rate_{}.json".format(present_day))
        if os.path.exists(record_path):
            with open(record_path,'r',encoding='utf-8') as file:
                history_file = json.load(file)

            history_file['scan_rate_record'].append(data)
            
        else:
            history_file = {"scan_rate_record":[data]}

        with open(record_path, 'w', encoding='utf-8') as file:
                json.dump(history_file, file)

    def read_uph(self,pre_time):
        pre_time_path = os.path.join(Configuration.RECORD_DIR,"uph_{}.json".format(pre_time.strftime('%Y-%m-%d')))
        pre_24_hours = pre_time +timedelta(hours=-24)
        pre_12_hours = pre_time.replace(minute=0,second=0)+timedelta(hours=-12)
        pre_24_hours_path = os.path.join(Configuration.RECORD_DIR,"uph_{}.json".format(pre_24_hours.strftime('%Y-%m-%d')))

        result_uph = []

        if os.path.exists(pre_24_hours_path):
            with open(pre_24_hours_path,'r',encoding='utf-8') as file:
                history_data = json.load(file)
            history_uph = history_data['uph_record']
            for index in range(len(history_uph)):
                if datetime.strptime(list(history_uph[index].keys())[0],"%Y-%m-%d_%H:%M:%S") >= pre_12_hours:
                    result_uph.append(history_uph[index])

        if os.path.exists(pre_time_path):
            with open(pre_time_path,'r',encoding='utf-8') as file:
                history_data = json.load(file)
            history_uph = history_data['uph_record']
            for index in range(len(history_uph)):
                if datetime.strptime(list(history_uph[index].keys())[0],"%Y-%m-%d_%H:%M:%S") >= pre_12_hours:
                    result_uph.append(history_uph[index])

        return result_uph
        

    def read_scan_rate(self,pre_time):
        pre_time_path = os.path.join(Configuration.RECORD_DIR,"scan_rate_{}.json".format(pre_time.strftime('%Y-%m-%d')))
        pre_24_hours = pre_time +timedelta(hours=-24)
        pre_12_hours = pre_time.replace(minute=0,second=0)+timedelta(hours=-12)
        pre_24_hours_path = os.path.join(Configuration.RECORD_DIR,"scan_rate_{}.json".format(pre_24_hours.strftime('%Y-%m-%d')))

        result_scan_rate = []

        if os.path.exists(pre_24_hours_path):
            with open(pre_24_hours_path,'r',encoding='utf-8') as file:
                history_data = json.load(file)
            history_uph = history_data['scan_rate_record']
            for index in range(len(history_uph)):
                if datetime.strptime(list(history_uph[index].keys())[0],"%Y-%m-%d_%H:%M:%S") >= pre_12_hours:
                    result_scan_rate.append(history_uph[index])

        if os.path.exists(pre_time_path):
            with open(pre_time_path,'r',encoding='utf-8') as file:
                history_data = json.load(file)
            history_uph = history_data['scan_rate_record']
            for index in range(len(history_uph)):
                if datetime.strptime(list(history_uph[index].keys())[0],"%Y-%m-%d_%H:%M:%S") >= pre_12_hours:
                    result_scan_rate.append(history_uph[index])

        return result_scan_rate
            