import atexit
from collections import OrderedDict, deque
from json.tool import main
import os
import signal
import socket
import sys
import threading
import time
import psutil
import requests
from requests.adapters import HTTPAdapter
from urllib3 import PoolManager


def get_local_ip():
    for interface, addrs in psutil.net_if_addrs().items():
        for addr in addrs:
            if addr.family == socket.AF_INET:
                local_ip = addr.address
                # 检查是否可以与服务器 IP 地址通信
                try:
                    if socket.create_connection(('172.28.131.236', 5000), 2):
                        return local_ip
                except socket.error:
                    continue

class LocalHostAdapter(HTTPAdapter):
    def __init__(self, local_ip, *args, **kwargs):
        self.local_ip = local_ip
        super().__init__(*args, **kwargs)

    def init_poolmanager(self, connections, maxsize, block=False, **pool_kwargs):
        pool_kwargs['source_address'] = (self.local_ip, 0)
        self.poolmanager = PoolManager(num_pools=connections, maxsize=maxsize, block=block, **pool_kwargs)
a = 0
def print_num():
    global a
    while True:
        print(a)
      
        time.sleep(1)

def read_num():
    global a
    while True:
        a= a + 1
        time.sleep(1)

def ready_to_clean(signal, frame):
    print("EXIT")
    sys.exit()

def clean_resorces(a):
    print("Clean",a)
    
        
# up_image_list = [f for f in os.listdir("./")]
# up_image_list.sort(key=os.path.getctime)
# print(up_image_list)
if __name__ == "__main__":
#    serial_port = {}
#    with open('USB.txt','r',encoding='utf-8') as data:
#             serial_list=data.readlines()
#    for serial_info in serial_list:
#         port_list = serial_info.split(">")[-1].split('/')
#         if port_list[7] == '1-4:1.0':
#             serial_port['plc_serial_port'] = "/dev/"+port_list[-1].replace("\n", '')
#         elif port_list[7] == '1-6:1.0':
#             serial_port['triple_light_port'] = "/dev/"+port_list[-1].replace("\n", '')
#    print(serial_port)
    # event = threading.Event()
    # print(event.isSet())
    # event.set()
    # print(event.isSet())
   pass
   
  