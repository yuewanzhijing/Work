from datetime import datetime, timedelta
import threading
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import random
from collections import deque
import time
# 初始化Dash应用
app = dash.Dash(__name__)

# 初始化数据
X = deque(maxlen=24)
Y = deque(maxlen=24)
X.append(datetime.now())
Y.append(1)

def generate_data():
    global X, Y
    current_time = datetime.now()
    while True:
        # 每小时生成一个数据点
        if len(list(X)) == 0 or current_time >= list(X)[-1] + timedelta(minutes=10):
            list(X).append(current_time)
            list(Y).append(random.randint(0, 650)) # 随机生成数据量
            current_time += timedelta(minutes=10)
        time.sleep(1)  # 每秒检查一次

# 启动数据生成线程
data_thread = threading.Thread(target=generate_data, daemon=True)
data_thread.start()

# 定义应用布局
app.layout = html.Div(
    [
        dcc.Graph(id="live-graph",animate=True),
        dcc.Interval(
            id="graph-update",
            interval=1000,  # 更新间隔为1000毫秒（1秒）
            n_intervals=0,
        ),
        html.Div(id="number-display-1", style={'fontSize': 24, 'marginTop': 20}),
        html.Div(id="number-display-2", style={'fontSize': 24, 'marginTop': 20}),
    ]
)

# 定义回调函数来更新图表和数字
@app.callback(
    [Output("live-graph", "figure"),
     Output("number-display-1", "children"),
     Output("number-display-2", "children")],
    [Input("graph-update", "n_intervals")]
)
def update_graph_and_numbers(n):
    # 更新数据
    # X.append(X[-1] + timedelta(minutes=10))
    # Y.append(Y[-1] + (random.uniform(-0.1, 0.1)))  # 随机变化的数据

    # 创建图表
    data = go.Scatter(
        x=list(X),
        y=list(Y),
        mode="lines+markers",
    )

    # 生成随机数字或计算的数字
    number1 = round(random.uniform(0, 100), 2)
    number2 = round(random.uniform(0, 100), 2)

    # 返回图表和数字的更新内容
    return {
        "data": [data],
        "layout": go.Layout(
            title='每小时数据量动态显示',
            xaxis_title='时间',
            yaxis_title='数据量',
            xaxis=dict(type='date'),
            yaxis=dict(range=[min(Y), max(Y)]),
        ),
    }, f"Number 1: {number1}", f"Number 2: {number2}"

if __name__ == "__main__":
    app.run_server(debug=True)