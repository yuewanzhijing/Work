from collections import deque
import threading


UPH_TIME = deque(maxlen=12)
UPH_PER_HOUR = deque(maxlen=12)
SCAN_TIME = deque(maxlen=12)
SCAN_RATE_PER_HOUR = deque(maxlen=12)



UP_IMAGE_INFO_TABLE = deque(maxlen=20)
DOWN_IMAGE_INFO_TABLE = deque(maxlen=20)

PREDICT_RESULT = {}
THREE_COLOR_LIGHT_CLOCK = threading.Lock()
ADD_PREDICT_RESULT = False
TRIGGER_THREE_LIGHT = deque([False,False],maxlen=2)