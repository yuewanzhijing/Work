import os
import modbus_tk.defines as cst
import cv2
import time
from PIL import Image
from datetime import datetime,timedelta
from globals import *
from configuration import Configuration
from record import HistoryRecord
import globals



class Cosmetic:
    
    codeName1=deque(maxlen=2)
    codeName2=deque(maxlen=3)
    lock = threading.Lock()
    Img1=None
    Img2=None
    
    per_hour_uph_state = {}
    per_hour_uph_complete = 0

    UPH_LAST_HOUR = 0
    SCAN_RATE_LAST_HOUR = 0.0

    added = False
    ord_num = {"1":"st","2":"nd","3":"rd"}
    already_scan = False
    in_position = False
    
    def __init__(self,Plc,Tool):
        self.plc=Plc
        self.tool = Tool
        self._init_image_queue()
    
    def _init_image_queue(self):
        up_image_list = [os.path.join(Configuration.ImageUpDir, f) for f in os.listdir(Configuration.ImageUpDir) if f.lower().endswith(('.jpg','.jpeg'))]
        up_image_list.sort(key=os.path.getctime)
        down_image_list = [os.path.join(Configuration.ImageDownDir, f) for f in os.listdir(Configuration.ImageDownDir) if f.lower().endswith(('.jpg','.jpeg'))]
        down_image_list.sort(key=os.path.getctime)
        self.up_image_queue = deque(up_image_list)
        self.down_image_queue = deque(down_image_list)

    def _save_image_to_local(self,image_dir,image_name,image,quality):
        image_path_name = os.path.join(image_dir,image_name)
        cv2.imwrite(image_path_name,image,[int(cv2.IMWRITE_JPEG_QUALITY),quality])
        if image_dir == Configuration.ImageUpDir:
            if image_path_name in self.up_image_queue:
                self.up_image_queue.remove(image_path_name)
            self.up_image_queue.append(image_path_name)
        elif image_dir == Configuration.ImageDownDir:
            if image_path_name in self.down_image_queue:
                self.down_image_queue.remove(image_path_name)
            self.down_image_queue.append(image_path_name)

    def __compress_image(self,input_path,output_path,quality):
        img=Image.open(input_path)
        if img.format == "JPEG" or img .format == "JPG":
            img.save(output_path,img.format,quality =quality,optimize=True)
        else:
            self.tool.printError("图片格式不是.jpg或.jpeg",True)
            raise Exception("图片格式有误,无法使用此方法压缩")

    def scan_code(self,scanner,thread_event):
        M0=2048
        M1=2049
        M2=2050
        times=1
        hour_successes = 0
        one_hour_time = 0
        master=self.plc
        histry_record = HistoryRecord()
        try:
            while True:
                while (master.execute(slave = 1,function_code = cst.READ_COILS,starting_address = M0,quantity_of_x=1))[0]!=1:
                    time.sleep(0.25)
                if thread_event.isSet():
                        break
                Cosmetic.added = False
                self.tool.print(f"The host received a signal for the {times}{Cosmetic.ord_num.get(str(times),'th')} time that it can scan QR code.",True)
                if times == 1:
                    one_hour_later = datetime.now().replace(minute=0,second=0) + timedelta(hours=1)
                if datetime.now() > one_hour_later:
                    SCAN_TIME.append(one_hour_later)
                    one_hour_success_rate = 0
                    if one_hour_time > 0:
                        one_hour_success_rate = round(hour_successes / one_hour_time,2) * 100
                    SCAN_RATE_PER_HOUR.append(one_hour_success_rate)
                    Cosmetic.SCAN_RATE_LAST_HOUR = one_hour_success_rate

                    UPH_TIME.append(one_hour_later)
                    UPH_PER_HOUR.append(Cosmetic.per_hour_uph_complete)
                    Cosmetic.UPH_LAST_HOUR = Cosmetic.per_hour_uph_complete

                    string_format = one_hour_later.strftime("%Y-%m-%d_%H:%M:%S")
                    histry_record.write_scan_rate({string_format:one_hour_success_rate})
                    histry_record.write_uph({string_format:Cosmetic.per_hour_uph_complete})
                    


                    Cosmetic.per_hour_uph_complete = 0
                    hour_successes = 0
                    one_hour_time = 0
                    one_hour_later = one_hour_later + timedelta(hours=1)

                
                
                code=scanner.getBarcode()
                if ("NR"!=code):
                    with Cosmetic.lock:
                        Cosmetic.codeName1.append(code)
                        Cosmetic.codeName2.append(code)
                        Cosmetic.added = True
                    Cosmetic.already_scan = True
                    PREDICT_RESULT[code] = {"up_image_predict_result":"","down_image_predict_result":""}
                    master.execute(1,cst.WRITE_SINGLE_COIL,M1,quantity_of_x=1,output_value=1)
                    self.tool.print(f"Sent a signal to the PLC that the {times}{Cosmetic.ord_num.get(str(times),'th')} QR code scan was a success",True)
                    hour_successes = hour_successes + 1
                    Cosmetic.per_hour_uph_state[code] = 1
                else:
                    master.execute(1,cst.WRITE_SINGLE_COIL,M2,quantity_of_x=1,output_value=1)
                    self.tool.printError(f"Sent a signal to the PLC that the {times}{Cosmetic.ord_num.get(str(times),'th')} QR code scan was a failure",True)
                one_hour_time = one_hour_time + 1
                times=times+1
        except Exception as e:
            self.tool.printError(f"扫码线程异常!!! :{e}",False)
            raise

    def take_image_up(self,CameraUp,thread_event):
        M10=2058
        M11=2059
        M12=2060
        master=self.plc
        quality=Configuration.UpImageQuality
        times=1
        up_image_name = ""
        try:
            while True:
                    while (master.execute(slave = 1,function_code = cst.READ_COILS,starting_address = M10,quantity_of_x=1))[0]!=1:
                        time.sleep(0.25)
                    if thread_event.isSet():
                        break
                    self.tool.print(f"The host received a signal for the {times}{Cosmetic.ord_num.get(str(times),'th')} time that it can capture an image from above",True)
                    while (len(Cosmetic.codeName1)==0):
                        time.sleep(0.2)
                    with Cosmetic.lock:
                        if len(Cosmetic.codeName1) == 2 and Cosmetic.added:
                            up_image_name = Cosmetic.codeName1.popleft()
                        else:
                            up_image_name = Cosmetic.codeName1.pop()
                    Cosmetic.Img1=CameraUp.get_image()
                    if (not Cosmetic.Img1 is None):
                        cv2.imwrite(f"{Configuration.DataSetDir}/{up_image_name}.jpg",Cosmetic.Img1,[int(cv2.IMWRITE_JPEG_QUALITY),quality])
                        self.tool.print(f"The camera successfully captured an image from above and named it {up_image_name}.jpg",writeLog=True)
                        if len(self.up_image_queue) >= Configuration.ImageUpNum:
                            dele_image_path = self.up_image_queue.popleft()
                            if os.path.exists(dele_image_path):
                                os.remove(dele_image_path)
                        self._save_image_to_local(f"{Configuration.ImageUpDir}",f"{up_image_name}.jpg",Cosmetic.Img1,quality)
                        master.execute(1,cst.WRITE_SINGLE_COIL,M11,quantity_of_x=1,output_value=1)
                        self.tool.print(f"Sent a signal to the PLC that the {times}{Cosmetic.ord_num.get(str(times),'th')} image capture from above was a success",True)
                        if up_image_name in Cosmetic.per_hour_uph_state:
                            Cosmetic.per_hour_uph_state[up_image_name] = Cosmetic.per_hour_uph_state[up_image_name] + 1
                    else:
                        self.tool.printError(f"The capture of the {times}{Cosmetic.ord_num.get(str(times),'th')} image named {up_image_name}.jpg from above was a failure",writeLog=True)
                        master.execute(1,cst.WRITE_SINGLE_COIL,M12,quantity_of_x=1,output_value=1)
                        self.tool.printError(f"Sent a signal to the PLC that the {times}{Cosmetic.ord_num.get(str(times),'th')} image capture from above was a failure",True)
                    times=times+1
        except Exception as e:
            self.tool.printError(f"上相机拍照线程异常!!! :{e}")
            raise
       
    def take_image_down(self,CameraDown,thread_event):
        M20=2068
        M21=2069
        M22=2070
        master=self.plc
        quality=Configuration.DownImageQuality
        times=1
        down_image_name = ""
        try:
            while True:
                    while (master.execute(slave = 1,function_code = cst.READ_COILS,starting_address = M20,quantity_of_x=1))[0]!=1:
                        time.sleep(0.25)
                    if thread_event.isSet():
                        break
                    Cosmetic.in_position = True
                    with THREE_COLOR_LIGHT_CLOCK:
                        globals.ADD_PREDICT_RESULT = False
                    self.tool.print(f"The host received a signal for the {times}{Cosmetic.ord_num.get(str(times),'th')} time that it can capture an image from below",True)
                    while len(Cosmetic.codeName2) == 0:
                        time.sleep(0.25)
                    time.sleep(Configuration.delayTime)
                    Cosmetic.Img2=CameraDown.get_image()
                    with Cosmetic.lock:
                        if len(Cosmetic.codeName2) == 3:
                            if Cosmetic.added:
                                down_image_name = Cosmetic.codeName2.popleft()
                            else:
                                Cosmetic.codeName2.popleft()
                                down_image_name = Cosmetic.codeName2.popleft()
                        else:
                            down_image_name = Cosmetic.codeName2.popleft()
                    if (not Cosmetic.Img2 is None):
                        cv2.imwrite(f"{Configuration.DataSetDir}/{down_image_name}.jpeg",Cosmetic.Img2,[int(cv2.IMWRITE_JPEG_QUALITY),quality])
                        self.tool.print(f"The camera successfully captured an image from below and named it {down_image_name}.jpeg",writeLog=True)
                        if len(self.down_image_queue) >= Configuration.ImageDownNum:
                            dele_image_path = self.down_image_queue.popleft()
                            if os.path.exists(dele_image_path):
                                os.remove(dele_image_path)
                        self._save_image_to_local(f"{Configuration.ImageDownDir}",f"{down_image_name}.jpeg",Cosmetic.Img2,quality)
                        master.execute(1,cst.WRITE_SINGLE_COIL,M21,quantity_of_x=1,output_value=1)
                        self.tool.print(f"Sent a signal to the PLC that the {times}{Cosmetic.ord_num.get(str(times),'th')} image capture from below was a success",True)
                    else:
                        self.tool.printError(f"The capture of the {times}{Cosmetic.ord_num.get(str(times),'th')} image named {down_image_name}.jpeg from below was a failure",writeLog=True)
                        master.execute(1,cst.WRITE_SINGLE_COIL,M22,quantity_of_x=1,output_value=1)
                        self.tool.printError(f"Sent a signal to the PLC that the {times}{Cosmetic.ord_num.get(str(times),'th')} image capture from below was a failure",True)
                    if down_image_name in Cosmetic.per_hour_uph_state:
                        if Cosmetic.per_hour_uph_state[down_image_name] == 2:
                            Cosmetic.per_hour_uph_complete = Cosmetic.per_hour_uph_complete + 1
                        del Cosmetic.per_hour_uph_state[down_image_name]
                    
                    times=times+1
        except Exception as e:
            self.tool.printError(f"下相机拍照线程异常!!! :{e}",False)
            raise

    def monitor_reset_button(self,thread_event):
        M102=2150
        master = self.plc
        try:
            while True:
                if (master.execute(1,cst.READ_COILS,M102,quantity_of_x=1)[0] == 1):
                    self.tool.print('机器已经复位完成!!!',writeLog=True)
                    if Cosmetic.already_scan:
                        thread_event.set()
                        self.tool.printWarning('请重启程序!!!',writeLog=True)
                        break
                time.sleep(1)
        except Exception as e:
            self.tool.printError(f"复位过程异常!!! :{e}",False)
            raise

    def control_triple_color_light(self,three_color_light):
        M20=2068
        master=self.plc
        command = False
        while True:
            while (not Cosmetic.in_position or master.execute(slave = 1,function_code = cst.READ_COILS,starting_address = M20,quantity_of_x=1)[0]!=1):
                time.sleep(0.25)
            Cosmetic.in_position = False
            with THREE_COLOR_LIGHT_CLOCK:
                if globals.ADD_PREDICT_RESULT:
                    command = TRIGGER_THREE_LIGHT[0]
                else:
                    command = TRIGGER_THREE_LIGHT[-1]
            if command:
                try:
                    three_color_light.write(Configuration.RedlightBlinking)
                    time.sleep(0.1)
                    three_color_light.write(Configuration.BuzzerModeOne)
                    time.sleep(Configuration.Alarm_Duration)
                    three_color_light.write(Configuration.TurnOffRedLight)
                    time.sleep(0.1)
                    three_color_light.write(Configuration.TurnOffBuzzer)
                    time.sleep(0.1)
                    three_color_light.write(Configuration.GreenLightAlwaysOn)
                except Exception as e:
                    self.log.printError(f"三色灯执行指令异常!!! :{e}",False)
                    raise
    
 
    def recover(self):
        M197=2245
        M198=2246
        M199=2247
        M102=2150
        master=self.plc
        master.set_timeout(1)
        try :
            master.execute(1,cst.WRITE_SINGLE_COIL,M197,quantity_of_x=1,output_value=1)
            self.tool.print('Stop button is pressed',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        time.sleep(0.5)
        try :
            master.execute(1,cst.WRITE_SINGLE_COIL,M197,quantity_of_x=1,output_value=0)
            self.tool.print('Stop button is released',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        time.sleep(0.25)
        try:
            master.execute(1,cst.WRITE_SINGLE_COIL,M199,quantity_of_x=1,output_value=1)
            self.tool.print('Recover button is pressed',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        try:
            master.execute(1,cst.WRITE_SINGLE_COIL,M199,quantity_of_x=1,output_value=0)
            self.tool.print('Recover button is released',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        try:
            Flag=master.execute(1,cst.READ_COILS,M102,quantity_of_x=1)
            self.tool.print('Plate rotates',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        while Flag[0]!=1:
            Flag=master.execute(1,cst.READ_COILS,M102,quantity_of_x=1)
            self.tool.print('Plate is rotating',writeLog=True)
        self.tool.print('Plate stoped',writeLog=True)
        try:
            master.execute(1,cst.WRITE_SINGLE_COIL,M198,quantity_of_x=1,output_value=1)
            self.tool.print('Start-button is pressed',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))
        try :
            master.execute(1,cst.WRITE_SINGLE_COIL,M198,quantity_of_x=1,output_value=0)
            self.tool.print('Start-button is released',writeLog=True)
        except Exception as e:
            self.tool.printWarning('原因:{}'.format(e))