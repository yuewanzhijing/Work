#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import serial  # 导入串口通讯库
import serial.tools.list_ports


import serial
import serial.tools.list_ports
import time
import LightCommandCreater as lc
from Tool import Tool


class COM:
    def __init__(self, port, baud):
        self.port = port
        self.baud = int(baud)
        self.open_com = None
        self.get_data_flag = True
        self.real_time_data = ''
        self.Tool = Tool()

    # return real time data form com
    def get_real_time_data(self):
        return self.real_time_data

    def clear_real_time_data(self):
        self.real_time_data = ''

    # set flag to receive data or not
    def set_get_data_flag(self, get_data_flag):
        self.get_data_flag = get_data_flag

    def open(self):
        try:
            self.open_com = serial.Serial(self.port, self.baud)
        except Exception as e:
            self.Tool.printError(
                '[RS232] 開啟端口失敗:{}/{}'.format(self.port, self.baud))
            self.Tool.printError('[RS232] 原因:{}'.format(e))

    def close(self):
        if self.open_com is not None and self.open_com.isOpen:
            self.open_com.close()

    def send_data(self, data):
        if self.open_com is None:
            self.open()
        success_bytes = self.open_com.write(data.encode('UTF-8'))
        return success_bytes

    def get_data(self, time_out_sec=4):
        all_data = ''
        if self.open_com is None:
            self.open()
        start_time = time.time()
        while True:
            # data = self.open_com.read(self.open_com.inWaiting())
            data = self.open_com.read() # read 1 size
            data = str(data, "utf-8")
            # print(data)
            if data != '':
                all_data = all_data + data
                self.real_time_data = all_data
            elif len(all_data.replace("\\", "").replace("#", "")) == 8:
                break
            # elif time.time() - time_out_sec > start_time:
            #     break
        # print("[REV] {}".format(all_data.replace("\#","")))
        return all_data


def getallport():
    port_list = list(serial.tools.list_ports.comports())
    # print(port_list)

    if len(port_list) == 0:
        print("[RS232]无可用串口!")
        return None
    else:
        # for i in range(0, len(port_list)):
        #     print(port_list[i])
        return port_list


def getallport_info():
    plist = list(serial.tools.list_ports.comports())

    if len(plist) <= 0:
        print("[RS232] 未找到可用端口!")
        return []
    else:
        plist_0 = list(plist[0])
        print(plist_0)
        serialName = plist_0[0]
        serialFd = serial.Serial(serialName, 9600, timeout=60)
        print("[RS232] 檢查實際使用的端口 >", serialFd.name)
        return serialFd.name
    
# if __name__ == "__main__":
#     com = COM(getallport()[0].device,9600)
#     # com = COM('/dev/ttyUSB0',9600)
#     # com.send_data('M0')
#     # all_data=com.get_data()
#     # print(all_data)
#     com.send_data(lc.create_control_command(2,1,100))
#     # time.sleep(0.1)
#     com.send_data(lc.create_control_command(2,4,100))
#     # # time.sleep(0.1)
#     com.send_data(lc.create_control_command(2,2,100))
#     # # time.sleep(0.1)
#     com.send_data(lc.create_control_command(2,3,100))
    # com.send_data(lc.create_control_command(2,4,12))
    # print(com.get_data())
    # com.send_data(lc.create_control_command(2,2,230))
    # com.send_data(lc.create_control_command(2,3,230))
    # com.send_data(lc.create_control_command(2,4,230))
    
    # print(com)
    # print(com.get)
    # com.send_data(lc.create_control_command(3,1,255))
    # com.get_data()
    # print(getallport()[0])
