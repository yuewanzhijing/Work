from collections import deque
import random

import dash
from dash import dcc, html, Input, Output, dash_table
import plotly.graph_objs as go
from datetime import datetime, timedelta
# from dash import html

from RS232Controller import *
from BarcodeScanner import *
from HikvisionClass import *

UPH_TIME = deque(maxlen=264)
UPH_PER_5MIN = deque(maxlen=264)
SCAN_TIME = deque(maxlen=264)
SCAN_RATE_PER_5MIN = deque(maxlen=264)

UPH_LAST_HOUR = 0
SCAN_RATE_LAST_HOUR = 0.0

UP_IMAGE_INFO_TABLE = deque(maxlen=200)
DOWN_IMAGE_INFO_TABLE = deque(maxlen=200)



def generate_data():
        global SCAN_RATE_LAST_HOUR,UPH_LAST_HOUR
        current_time = datetime.now()
        while True:
            # 每5分钟生成一个数据点
            if len(UPH_TIME) == 0 or current_time >= UPH_TIME[-1] + timedelta(minutes=5):
                UPH_TIME.append(current_time)
                UPH_PER_5MIN.append(random.randint(0, 650))  # 随机生成数据量
                SCAN_TIME.append(current_time)
                SCAN_RATE_PER_5MIN.append(random.randint(0, 650))
                SCAN_RATE_LAST_HOUR = round(random.uniform(0, 100), 2)
                UPH_LAST_HOUR = round(random.uniform(0, 100), 2)

                if len(UP_IMAGE_INFO_TABLE) < UP_IMAGE_INFO_TABLE.maxlen:
                    up_image_info_number = len(UP_IMAGE_INFO_TABLE) + 1
                else:
                    up_image_info_number = up_image_info_number + 1
                # 添加新数据到表格
                up_image_info_new_row = {
                    'no': up_image_info_number,
                    'upload_time': current_time.strftime('%Y-%m-%d %H:%M:%S'),
                    'sn': "DR9310202881L52AR+AA+NNNNNNNNNNN+J022J494452",
                    'predict_result': '12',
                    'sf_info': '开始预测 this is my little cat 我很喜欢'
                }
                UP_IMAGE_INFO_TABLE.append(up_image_info_new_row)

                if len(DOWN_IMAGE_INFO_TABLE) < DOWN_IMAGE_INFO_TABLE.maxlen:
                    down_image_info_number = len(DOWN_IMAGE_INFO_TABLE) + 1
                else:
                    down_image_info_number = down_image_info_number + 1
                # 更新另一个表格的数据
                down_image_info_new_row = {
                    'no': "352",
                    'upload_time': current_time.strftime('%Y-%m-%d %H:%M:%S'),
                    'sn': "DR9310202881L52AR+AA+NNNNNNNNNNN+J022J494452",
                    'predict_result': 'Non',
                    'sf_info': 'this is test 开始预测 this is my little cat',
                    'name':"k5ai"
                }
                DOWN_IMAGE_INFO_TABLE.append(down_image_info_new_row)
                current_time += timedelta(minutes=5)
            time.sleep(1)  # 每0.4秒检查一次

threading.Thread(target=generate_data, daemon=True).start()


class DashboardApp:
    def __init__(self):
        self.app = dash.Dash(__name__)
        # self.show_previous_record(history_record)
        # 设置应用布局
        self.app.layout = self.create_layout()

        # 设置回调
        self.set_callbacks()

    
        
    def create_layout(self):
        return html.Div(
            [
                html.Div(id='number-uph', style={'fontSize': 24, 'position': 'absolute', 'top': '2%', 'left': '20%'}),
                html.Div(id='number-scan-rate', style={'fontSize': 24, 'position': 'absolute', 'top': '2%', 'left': '70%'}),
                html.Div([
                    dcc.Graph(id='uph-update-graph', style={'margin-top': '3%', 'width': '50%','height': '100%'}),
                    dcc.Graph(id='scan-rate-update-graph', style={'margin-top': '3%', 'width': '50%','height': '100%'}),
                ], style={'display': 'flex','height': '30vh'}),
                dcc.Interval(
                    id='interval-component',
                    interval= 20 * 1000,  # 每0.4秒更新一次
                    n_intervals=0
                ),
                dcc.Interval(
                    id='table-interval-component',
                    interval= 2 * 1000,  # 每20秒更新一次
                    n_intervals=0
                ),
                html.Div([
    html.Div([
        dash_table.DataTable(
            id='data-table',
            columns=[
                {'name': 'No', 'id': 'no'},
                {'name': 'upload_time', 'id': 'upload_time'},
                {'name': 'SN', 'id': 'sn'},
                {'name': 'predict_result', 'id': 'predict_result'},
                {'name': 'sf_info', 'id': 'sf_info'},
            ],
            data=list(UP_IMAGE_INFO_TABLE),
            style_header={'backgroundColor': 'gray', 'color': 'white', 'position': 'sticky', 'top': 0, 'zIndex': 100},
            style_cell={'textAlign': 'center', 'minWidth': '50px'},
            style_table={
                'overflowY': 'auto',  # 当内容超出时显示滚动条
                'height': '70vh',     # 设置表格的高度
                'width': '100%'        # 设置表格的宽度
            },
            style_data_conditional=[
                {
                    'if': {'column_id': 'sf_info'},
                    'whiteSpace': 'normal',  # 让 Column 2 自动换行
                    'textAlign': 'left',      # sf_info 列内容左对齐
                    'height': 'auto',
                },
                {
                    'if': {'column_id': 'predict_result', 'filter_query': '{predict_result} ="None"'},
                'backgroundColor': 'red'}
            ],
        )
    ], style={'flex': '1'}),  # 第一个表格占据一半的空间
    
    html.Div([
        dash_table.DataTable(
            id='data-table2',
            columns=[
                {'name': 'No', 'id': 'no'},
                {'name': 'upload_time', 'id': 'upload_time'},
                {'name': 'SN', 'id': 'sn'},
                {'name': 'predict_result', 'id': 'predict_result'},
                {'name': 'sf_info', 'id': 'sf_info'},
            ],
            data=list(DOWN_IMAGE_INFO_TABLE),
            style_header={'backgroundColor': 'gray', 'color': 'white', 'position': 'sticky', 'top': 0, 'zIndex': 100},
            style_cell={'textAlign': 'center', 'minWidth': '50px'},
            style_table={
                'overflowY': 'auto',  # 当内容超出时显示滚动条
                'height': '70vh',     # 设置表格的高度
                'width': '100%'        # 设置表格的宽度
            },
            style_data_conditional=[
                {
                    'if': {'column_id': 'sf_info'},
                    'whiteSpace': 'normal',  # 让 Column 2 自动换行
                    'textAlign': 'left',      # sf_info 列内容左对齐
                    'height': 'auto',
                },
               {
                'if': {'column_id': ['no','upload_time','sn','predict_result','sf_info'],'filter_query': '{predict_result} ="None" || {no} ="32" || {name} ="kai"',},
                'backgroundColor': 'yellow'}
            ],
        )
    ], style={'flex': '1'})  # 第二个表格占据一半的空间
], style={'display': 'flex', 'margin-top': '2%'})  # 将两个表格放在同一行 # 将两个表格放在同一行
            ]
        )

    # 每0.4秒检查一次'height': '100vh', 'display': 'flex', 'flexDirection': 'column'

    def set_callbacks(self):
        @self.app.callback(
            Output('uph-update-graph', 'figure'), 
            Input('interval-component', 'n_intervals')
        )
        def update_uph(n):
            # 更新图表
            figure_uph = go.Figure()
            figure_uph.add_trace(go.Scatter(x=list(UPH_TIME), y=list(UPH_PER_5MIN), mode='lines+markers'))
            # 设置图表布局
            figure_uph.update_layout(
                margin=dict(t=30),
                xaxis_title='时间',
                yaxis_title='UPH',
                xaxis=dict(tickmode='linear', dtick=3600*1000, tickformat='%H:%M')  # 设置X轴为小时
            )
            return figure_uph  # 返回图表数据

        @self.app.callback(
            Output('scan-rate-update-graph', 'figure'), 
            Input('interval-component', 'n_intervals')
        )
        def update_scan_rate(n):
            # 更新图表
            figure_scan_rate = go.Figure()
            figure_scan_rate.add_trace(go.Scatter(x=list(SCAN_TIME), y=list(SCAN_RATE_PER_5MIN), mode='lines+markers',
                                                 line=dict(color='green')))
            # 设置图表布局
            figure_scan_rate.update_layout(
                margin=dict(t=30),
                xaxis_title='时间',
                yaxis_title='扫码率',
                xaxis=dict(tickmode='linear', dtick=3600*1000, tickformat='%H:%M')  # 设置X轴为小时
            )
            return figure_scan_rate

        @self.app.callback(
            Output('number-uph', 'children'),
            Input('interval-component', 'n_intervals')
        )
        def update_number_uph(n):
            # 直接使用生成线程中更新的数字
            return f"UPH: {UPH_LAST_HOUR}"
        
        @self.app.callback(
            Output('number-scan-rate', 'children'),
            Input('interval-component', 'n_intervals')
        )
        def update_number_scan_rate(n):
            # 直接使用生成线程中更新的数字
            return f"扫码率: {SCAN_RATE_LAST_HOUR}%"

        @self.app.callback(
            Output('data-table', 'data'),  # 添加输出以更新表格数据
            Input('table-interval-component', 'n_intervals')
        )
        def update_UP_IMAGE_INFO_TABLE(n):
            return list(UP_IMAGE_INFO_TABLE)  # 返回表格数据

        @self.app.callback(
            Output('data-table2', 'data'),  # 更新第二个表格的数据
            Input('table-interval-component', 'n_intervals')
        )
        def update_DOWN_IMAGE_INFO_TABLE(n):
            return list(DOWN_IMAGE_INFO_TABLE)  # 返回第二个表格的数据

    def run(self):
        self.app.run(debug=True)




if __name__ == '__main__':
    try:
        data_thread = threading.Thread(target=generate_data, daemon=True)
        data_thread.start()
        print("开始预测")
        dashboard = DashboardApp()
        dashboard.run()
    except Exception as e:
        print(e)
    
