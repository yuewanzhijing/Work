#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# 字符 => ASCII   ord(char))
# ASCII => 字符   chr(ASCII)
# 10 => 16        hex(16)
from functools import reduce


# 3100A67
# 3200A64
# 3300A65
# 3400A62
def create_control_command(order=3, gateway=1, light=0):
    # print("order:%d gateway:%d light:%d"%(order,gateway,light))
    try:
        light = int(light)
    except BaseException as e:

        print(e)
    if(not isinstance(order, int) or not isinstance(gateway, int) or not isinstance(light, int)):
        print("無效的指令")
        return None
    if light < 0 or light > 255:
        print("光源亮度參數必須为 0~255")
        return False
    # 補齊三位數字
    light = getascii16(light)
    light = str(light).rjust(3, '0').upper()
    command_arr = ["$", order, gateway, light[0], light[1], light[2]]
    command_ascii = []
    command_2_arr = []
    for item in command_arr:
        command_ascii.append(ord(str(item)))

    for item in command_ascii:
        command_2_arr.append(getascii2(item))
    command_xor_arr = []

    for i in range(8):
        temp_str = ""
        for item in command_2_arr:
            temp_str += item[i]
        command_xor_arr.append(temp_str)
    check_code = ""
    for item in command_xor_arr:
        check_code += str(count_xor(item))
    # 計算 校驗碼
    # print(str(getascii16(int(check_code[:4], 2))))
    # print(str(getascii16(int(check_code[4:], 2))))
    command_arr.append(str(getascii16(int(check_code[:4], 2))))
    command_arr.append(str(getascii16(int(check_code[4:], 2))))
    return reduce(lambda x, y: str(x) + str(y), command_arr)


def count_xor(arr):
    count = 0
    for i in range(len(arr)):
        if(str(arr[i - 1]) == "1"):
            count += 1
    if(count % 2 == 1):
        return 1
    else:
        return 0


# 指令 轉 ASCII 十六進制表現
def getascii16(c):
    c = hex(int(c))
    if(c.startswith('0x')):
        c = c[2:]
    return c


# 轉 8位 二進制
def getascii2(c):
    c = bin(int(c))
    if(c.startswith('0b')):
        c = c[2:]
    c = str(c).rjust(8, '0')
    return c


# if __name__ == "__main__":
#       print(create_control_command(3, 2, 10))
#     print(create_control_command(1, 1, 255))
#     print(create_control_command(1, 2, 255))
#     print(create_control_command(1, 3, 255))
#     print(create_control_command(1, 4, 255))


# $1125516
# $1225515
# $1325514
# $1425513

# $1125516
# $1225515
# $1325514
# $1425513

# $310C86D
# $3201410
# $3300511
# $3403111
