import test2
import ui
import threading

if __name__ == "__main__":
    threading.Thread(target=test2.ceshi).start()
    threading.Thread(target=ui.write).start()
    while True:
        pass