
import threading
import time
from glo import a
def write():
    while True:
        print(a)
        time.sleep(1)

# def read():
#     global a
#     while True:
#         print(a)
#         time.sleep(1)

if __name__ == "__main__":
    threading.Thread(target=write).start()
    threading.Thread(target=read).start()
    while True:
        pass