from collections import deque


a= []
