import time
from glo import a
def ceshi():
    while True:
        a.append(12)
        time.sleep(1)