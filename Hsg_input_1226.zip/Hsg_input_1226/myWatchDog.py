from datetime import datetime, timedelta
import shutil
from watchdog.events import FileSystemEventHandler
import time
import os
from prediction import BackUpServer, LocalPrediction, CambrianPrediction
from configuration import Configuration
from globals import UP_IMAGE_INFO_TABLE, DOWN_IMAGE_INFO_TABLE,PREDICT_RESULT,THREE_COLOR_LIGHT_CLOCK,TRIGGER_THREE_LIGHT
import globals

def wait_for_file_stability(file_path):
        previous_size = -1
        while True:
            current_size = os.path.getsize(file_path)
            if current_size == previous_size:
                break
            previous_size = current_size
            time.sleep(0.1)




# 定义事件处理器类
class MyHandler(FileSystemEventHandler):

    cambrian_prediction = CambrianPrediction()
    upload_backup_fail = set()
    upload_backup_success = set()
    upload_local_fail = set()
    upload_fail_info = {
        "hour_later":None,
        "fail_num":0,
        "next_retry_time":None
    }
    
    def __init__(self, Logger, table_record,three_color_light) -> None:
        super().__init__()
        self.log = Logger
        self.table_record = table_record
        self.up_record_number = 1
        self.down_record_number = 1
        self.predictior = None
        self.backupserver = None
        self.three_color_light = three_color_light
        self._open_green_light()
        self._init_predictor()
        self._ensure_dirs()
        self._delete_previous_saved_image([(Configuration.ImageUpDir,Configuration.ImageUpNum),(Configuration.ImageDownDir,Configuration.ImageDownNum)])
        self._process_failed_uploads()
        self._upload_pre_images()

    def _init_predictor(self):
        try:
            self.predictior = LocalPrediction(self.log)
            self.localserver_available = True
        except Exception as e:
            self.log.printError(e)
            self.backupserver = BackUpServer(self.log)
            self.localserver_available = False
            MyHandler.upload_fail_info['next_retry_time'] = datetime.now()+timedelta(minutes=Configuration.IntervalConnectToLocal)

    def _ensure_dirs(self):
        for path, message in [(Configuration.UpLoadFailDir, "上传BackUpServer成功文件夹"),(Configuration.UpLoadBackupFailDir, "上传BackUpServer失败文件夹"),
                              (Configuration.DataSetDir, "图片临时存储文件夹"),
                              (Configuration.ImageUpDir, "上相机图片存储文件夹"),(Configuration.ImageDownDir, "下相机图片存储文件夹") ]:
            if not os.path.isdir(path):
                os.makedirs(path)
                self.log.print(f"已创建{message}:{path}", True)
    
    def _delete_previous_saved_image(self,save_info):
        for directory,save_num in save_info:
            files = [os.path.join(directory, f) for f in os.listdir(directory) if f.lower().endswith(('.jpg','.jpeg'))]
            files.sort(key=os.path.getctime,reverse=True)
            dele_num = len(files) - save_num
            if dele_num > 0:
                dele_index = 0
                for _ in range(dele_num):
                    dele_index = dele_index - 1
                    os.remove(files[dele_index])
                    self.log.print(f"已删除 {files[dele_index]} !!!", True)

    def _process_failed_uploads(self):
        self._process_files(Configuration.UpLoadFailDir)
        self._process_files(Configuration.UpLoadBackupFailDir)

    def _upload_pre_images(self):
        self._process_files(Configuration.DataSetDir, length_check=Configuration.bSNLengthCheck, length_tuple=Configuration.iSNLength)

    def _process_files(self, dir_path, length_check=0, length_tuple=()):
        file_list = [f for f in os.listdir(dir_path) if f.lower().endswith(('.jpg', '.jpeg'))]
        for filename in file_list:
            result =  [{},None,None]
            sn, ext = self._get_filename_info(filename)
            source_file = os.path.join(dir_path, filename)
            if length_check and not len(sn) in length_tuple:
                self.log.printWarning(f"{filename} SN长度为{len(sn)}, 与{length_tuple}不符, 不会上传预测!!!")
                continue
            if dir_path == Configuration.DataSetDir or dir_path == Configuration.UpLoadBackupFailDir:
                result = self._on_predict(source_file,'True',False)
            elif self.localserver_available and dir_path == Configuration.UpLoadFailDir:
                try:
                    result = self._attempt_local_upload(source_file,'False')
                except Exception:
                    MyHandler.upload_local_fail.add(source_file)
            self.on_record(sn, self._camera_direction(ext), result)

    def on_created(self, event):
        file_path = event.src_path
        sn, ext = self._get_filename_info(file_path)
        wait_for_file_stability(file_path)
        result = self._on_predict(file_path,'True',True)
        self.on_record(sn, self._camera_direction(ext), result)

    def _get_filename_info(self, file_path):
        sn = os.path.splitext(os.path.basename(file_path))[0]
        ext = os.path.splitext(file_path)[1].lower()
        return sn, ext

    def _camera_direction(self, extension):
        return "UpCameraRecord" if extension in ('.jpg',) else "DownCameraRecord"
    
    def _move_image(self,src,dst):
        if not os.path.abspath(src) == os.path.abspath(dst):
            if os.path.exists(dst):
                os.remove(dst)
            shutil.move(src,dst)

    def _on_predict(self, file_path,upload_sfis,triple_light_vali):
        result = [{},None,None]
        sn,ext = self._get_filename_info(file_path)
        if self.localserver_available:
            try:
                result = self._attempt_local_upload(file_path,upload_sfis)
            except Exception :
                MyHandler.upload_fail_info['fail_num'] = MyHandler.upload_fail_info['fail_num'] + 1
                if MyHandler.upload_fail_info['hour_later'] is None:
                    MyHandler.upload_fail_info['hour_later'] = datetime.now()+timedelta(hours=1)
                else:
                    if MyHandler.upload_fail_info['hour_later'] >= datetime.now():
                        if  MyHandler.upload_fail_info['fail_num'] >=5 :
                            self.localserver_available = False
                            if MyHandler.upload_fail_info['next_retry_time'] is None:
                                MyHandler.upload_fail_info['next_retry_time'] = datetime.now()+timedelta(minutes=Configuration.IntervalConnectToLocal)
                            MyHandler.upload_fail_info['hour_later'] = None
                            MyHandler.upload_fail_info['fail_num'] = 0
                    else:
                        MyHandler.upload_fail_info['hour_later'] = None
                        MyHandler.upload_fail_info['fail_num'] = 0
                MyHandler.upload_local_fail.add(file_path)
        else:
                if  MyHandler.upload_fail_info['next_retry_time'] <= datetime.now():
                    MyHandler.upload_fail_info['next_retry_time'] = MyHandler.upload_fail_info['next_retry_time']+timedelta(minutes=Configuration.IntervalConnectToLocal)
                    try:
                        if self.predictior is None:
                            self.predictior = LocalPrediction(self.log)
                        result = self._attempt_local_upload(file_path,upload_sfis)
                        self.localserver_available = True
                    except Exception as e:
                        self.log.printError(f"{Configuration.LocalServerIp} 预测失败!!! {e}")
                        MyHandler.upload_local_fail.add(file_path)
                else:
                    result = self._attempt_backup_upload(file_path)
        if result[0] != {} and (not self.three_color_light is None) and triple_light_vali:
            self._record_predict_result(sn,ext,result[0].get('result',''))
        
        return result

    def _attempt_local_upload(self, file_path,upload_sfis):
        result = [{},None,None]
        if os.path.exists(file_path):
            try:
                result[1] = datetime.now()
                if "Local" == Configuration.predictUrl:
                    self.log.print(f"开始上传{file_path}",True)
                    result[0] = self.predictior.predict(file_path,upload_sfis)
                elif "Cambrian" == Configuration.predictUrl:
                    self.log.print(f"开始上传{file_path}",True)
                    result[0] = MyHandler.cambrian_prediction.predict(file_path)
                result[2] = datetime.now()
                self.log.print(f"已获取到{file_path}的预测结果: {result[0]}",True)
                os.remove(file_path)
            except Exception as e:
                self.log.printError(f"{Configuration.LocalServerIp} 预测 {file_path}失败: {e},即将上传到 {Configuration.BackUpServerIpUploadUrl}",True)
                raise
        return result

    def _attempt_backup_upload(self, fail_file_path):
        result = [{},None,None]
        if os.path.exists(fail_file_path):
            basename = os.path.basename(fail_file_path)
            back_up_fail_path = os.path.join(Configuration.UpLoadBackupFailDir,basename)
            back_up_success_path = os.path.join(Configuration.UpLoadFailDir,basename)
            try:
                if self.backupserver is None:
                        self.backupserver = BackUpServer(self.log)
            except Exception as e:
                self.log.printError(f"连接到{Configuration.BackUpServerIp}:{Configuration.BackUpServerIpPort}失败!!!")
                self._move_image(fail_file_path,back_up_fail_path)
                MyHandler.upload_backup_fail.add(back_up_fail_path)
            else:
                    try:
                        sn = self._get_filename_info(fail_file_path)[0]
                        result[1] = datetime.now()
                        result[0] = self.backupserver.upload(sn)
                        result[2] = datetime.now()
                        self.log.print(f"已从{Configuration.BackUpServerIpUploadUrl}获取到{fail_file_path}的预测结果: {result[0]}",True)
                        self._move_image(fail_file_path,back_up_success_path)
                        MyHandler.upload_backup_success.add(back_up_success_path)
                    except Exception as e:
                        self.log.printError(f"{fail_file_path}上传失败: {e}",True)
                        self._move_image(fail_file_path,back_up_fail_path)
                        MyHandler.upload_backup_fail.add(back_up_fail_path) 
        return result

    def on_record(self, sn, camera_direction, result):
        record_data = {
            'no': self.up_record_number if camera_direction == "UpCameraRecord" else self.down_record_number,
            'upload_time': result[1].strftime('%Y-%m-%d %H:%M:%S') if result[1] else "None",
            'sn': sn,
            'predict_result': result[0].get('result', "None"),
            'sf_result': result[0].get('sfis_result', "None"),
            'sf_info': result[0].get('sfis_str', "None"),
            'get_result_time': result[2].strftime('%Y-%m-%d %H:%M:%S') if result[2] else "None",
            'interval': str(result[2] - result[1]) if result[1] and result[2] else "None"
        }
        if camera_direction == "UpCameraRecord":
            UP_IMAGE_INFO_TABLE.appendleft(record_data)
            self.up_record_number += 1
        elif camera_direction == "DownCameraRecord":
            DOWN_IMAGE_INFO_TABLE.appendleft(record_data)
            self.down_record_number += 1
        self.table_record.write_record(camera_direction, [record_data])
    
    def reupload(self):
       while True:
            time.sleep(Configuration.repredictInterval)
            fail_file_path = None
            upload_sfis = 'True'
            if len(MyHandler.upload_local_fail) > 0 :
                    fail_file_path =MyHandler.upload_local_fail.pop()
                    ori_dir = os.path.dirname(fail_file_path)
                    if os.path.abspath(ori_dir) == os.path.abspath(Configuration.UpLoadFailDir):
                        upload_sfis = 'False'
                    result = self._on_predict(fail_file_path,upload_sfis,False)
            elif self.localserver_available and len(MyHandler.upload_backup_success) > 0:
                    fail_file_path =MyHandler.upload_backup_success.pop()
                    try:
                        result = self._attempt_local_upload(fail_file_path,'False')
                    except Exception :
                        MyHandler.upload_backup_success.add(fail_file_path)
            elif len(MyHandler.upload_backup_fail) > 0:
                fail_file_path =MyHandler.upload_backup_fail.pop()
                result = self._on_predict(fail_file_path,upload_sfis,False)
            if not fail_file_path is None:
                    name_info = self._get_filename_info(fail_file_path)
                    sn = name_info[0]
                    camera_up_or_dwon= self._camera_direction(name_info[1])
                    self.on_record(sn,camera_up_or_dwon,result)

    def on_deleted(self, event):
        self.log.printWarning(f"{event.src_path} 已删除!!!" if self.localserver_available else f"{event.src_path} 已移动到 {Configuration.UpLoadFailDir}!!!")

    def _record_predict_result(self,sn,ext,predict_result):
        if '.jpeg' == ext:
            PREDICT_RESULT[sn]['down_image_predict_result'] = predict_result
        elif '.jpg' == ext:
             PREDICT_RESULT[sn]['up_image_predict_result'] = predict_result
        self._record_triple_light_command(sn)

    def _record_triple_light_command(self,sn):
        if (PREDICT_RESULT[sn]['up_image_predict_result'] != "" and PREDICT_RESULT[sn]['down_image_predict_result'] != ""):
                with THREE_COLOR_LIGHT_CLOCK:
                    if(PREDICT_RESULT[sn]['up_image_predict_result'] == "FAIL" or PREDICT_RESULT[sn]['down_image_predict_result'] == "FAIL"):
                            TRIGGER_THREE_LIGHT.append(True)
                    else:

                            TRIGGER_THREE_LIGHT.append(False)
                    globals.ADD_PREDICT_RESULT = True
                del PREDICT_RESULT[sn]
    

    def _open_green_light(self):
        if not self.three_color_light is None:
            self.three_color_light.write(Configuration.GreenLightAlwaysOn)

class BackUpHandler(FileSystemEventHandler):
    def __init__(self,Logger) -> None:
        super().__init__()
        self.log = Logger
        
    def on_created(self, event):
        
        file_path = event.src_path
        wait_for_file_stability(file_path)
        
        self.log.printWarning(f"已暂存predict为None或上传失败的图片{file_path}",True)

    def on_deleted(self, event):
        self.log.printWarning(f"{event.src_path} 已删除!!!")





